'use strict';

// The guided diagnosis: for the symptom a user names, the checks the
// Manager can run itself over facts it already has, the status sheet, the
// screen's facts, the release state and Glass's last lines in the journal.
// Every check is pure, facts in and a finding or nothing out, and stands
// for one cause the Troubleshooting page knows. A finding names its check,
// its kind (a likely cause, something worth knowing, or a thing checked
// and found right), the string that says it with the values to fill in,
// and the Manager's tab where it is set, when there is one.

const SYMPTOMS = ['no-meters', 'not-moving', 'restarts', 'touch', 'screen', 'artwork', 'remotes', 'face', 'look', 'forecast', 'browse', 'slow', 'other'];
const graphicsFault = require('./graphics').fault;

// A size as the sheet writes it, `1280x720`, as numbers; null for anything else.
function sizeOf(text) {
  const m = /^(\d+)x(\d+)$/.exec(String(text || '').trim());
  return m ? { w: parseInt(m[1], 10), h: parseInt(m[2], 10) } : null;
}

const cause = (check, key, fill, go) => ({ check, kind: 'cause', key, with: fill || {}, go: go || null });
const note = (check, key, fill, go) => ({ check, kind: 'note', key, with: fill || {}, go: go || null });
const ok = (check, key, fill) => ({ check, kind: 'ok', key, with: fill || {}, go: null });

// A journal line's time: the short-iso stamp it opens with.
function lineTime(line) {
  const m = /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})([+-]\d{2}):?(\d{2})/.exec(String(line));
  return m ? Date.parse(m[1] + m[2] + ':' + m[3]) : NaN;
}

// Glass's lines since the backend last started: what an earlier run said
// is no evidence about this one.
function linesOfThisRun(f) {
  const up = Number(f.status && f.status.sheet && f.status.sheet.player && f.status.sheet.player.backendUptimeS);
  const since = f.now && up >= 0 ? f.now - up * 1000 : NaN;
  return (f.log || []).filter(function (line) {
    const at = lineTime(line);
    return isNaN(since) || isNaN(at) || at >= since - 1000;
  });
}

const playing = (f) => f.status.channel && f.status.channel.status === 'play';
const megabytes = (bytes) => Math.round(bytes / 1048576);

const CHECKS = [
  // ---- for every symptom ---------------------------------------------
  {
    id: 'release', symptoms: SYMPTOMS,
    run(f) {
      const u = f.update;
      if (!u || !u.latest || !u.latest.version) return null;
      return u.available ? note('release', 'DIAG_RELEASE_NEWER', { current: u.current, latest: u.latest.version }, 'system')
        : ok('release', 'DIAG_RELEASE_CURRENT', { current: u.current });
    }
  },
  {
    id: 'legacy', symptoms: SYMPTOMS,
    run(f) { return f.status.legacy ? cause('legacy', 'DIAG_LEGACY_ON') : null; }
  },
  {
    id: 'binary', symptoms: SYMPTOMS,
    run(f) { return f.status.binary === false ? cause('binary', 'DIAG_NO_BINARY', { arch: f.status.arch || '?' }) : null; }
  },
  {
    id: 'disk', symptoms: SYMPTOMS,
    run(f) {
      const free = f.status.diskFree;
      return typeof free === 'number' && free < 100 * 1048576 ? cause('disk', 'DIAG_DISK_FULL', { mb: megabytes(free) }) : null;
    }
  },
  {
    id: 'journal', symptoms: SYMPTOMS,
    run(f) {
      const house = f.status.sheet && f.status.sheet.housekeeping;
      const problems = house && Array.isArray(house.problems) ? house.problems : [];
      return problems.length ? note('journal', 'DIAG_JOURNAL_PROBLEMS', { lines: problems.join('\n') }, 'system') : null;
    }
  },

  // ---- the meters never appear ----------------------------------------
  {
    id: 'output', symptoms: ['no-meters'],
    run(f) { return f.status.headless ? cause('output', 'DIAG_HEADLESS') : null; }
  },
  {
    id: 'playing', symptoms: ['no-meters', 'not-moving'],
    run(f) {
      const status = (f.status.channel && f.status.channel.status) || '?';
      return playing(f) ? ok('playing', 'DIAG_PLAYING') : cause('playing', 'DIAG_NOT_PLAYING', { status, timeout: f.status.timeout });
    }
  },
  {
    id: 'somewhere', symptoms: ['no-meters', 'restarts', 'screen'],
    run(f) {
      const sc = f.screen;
      if (!sc || !sc.fact || !sc.now) return null;
      // Where glass-evo holds the screen the kiosk is not meant to run: its
      // unit standing as failed (a take before 0.8.18 left it so) is no cause.
      const evo = !!(sc.owner && sc.owner.owner === 'glass-evo');
      if (sc.fact.kiosk === 'failed' && !evo) return cause('somewhere', 'DIAG_KIOSK_FAILED');
      if (sc.now.wouldDraw || (sc.now.display && sc.now.display.running)) return null;
      return !sc.fact.panel && !sc.fact.xserver ? cause('somewhere', 'DIAG_NO_PANEL') : cause('somewhere', 'DIAG_KIOSK_ON_ITS_WAY', { kiosk: sc.fact.kiosk || '?' });
    }
  },
  {
    id: 'display', symptoms: ['no-meters'],
    run(f) {
      if (!playing(f) || f.status.headless) return null;
      return f.status.running ? ok('display', 'DIAG_DISPLAY_UP') : note('display', 'DIAG_DISPLAY_NOT_UP', { timeout: f.status.timeout });
    }
  },
  {
    id: 'deaths', symptoms: ['no-meters', 'restarts'],
    run(f) {
      const lines = linesOfThisRun(f);
      if (lines.some((l) => /missing or is the wrong CPU/.test(l))) return cause('deaths', 'DIAG_LOG_WRONG_BINARY', { arch: f.status.arch || '?' });
      // A window that would not open, in the display's own words: SDL's
      // for a driver or a window it could not have, or the display's for
      // a player with nothing to draw on. The line that sums a death up
      // repeats them and is not counted twice.
      const window = lines.filter((l) => !/the display did not run/.test(l) &&
        /glass: (SDL error: |x11 not available|wayland not available|kmsdrm not available|No available video device|no screen to draw on)/.test(l));
      if (window.length) return cause('deaths', 'DIAG_LOG_NO_WINDOW', { count: window.length, last: window[window.length - 1].replace(/^.*?glass:\s*/, '') });
      const died = lines.filter((l) => /the display died \d+ s after launch/.test(l));
      if (died.length) return cause('deaths', 'DIAG_LOG_DIED', { count: died.length, last: died[died.length - 1].replace(/^.*?glass:\s*/, '') }, 'system');
      return ok('deaths', 'DIAG_LOG_NO_DEATHS', { lines: lines.length });
    }
  },

  {
    // Whether the system's graphics can draw on a screen of the display's
    // own (the Manager's check: the display's probe, the kiosk's X log).
    id: 'graphics', symptoms: ['no-meters', 'restarts', 'screen'],
    run(f) {
      const g = f.screen && f.screen.graphics;
      if (!g || !g.asked) return null;
      if (g.applies && g.ok === false) {
        // The system faults the Troubleshooting page knows, each with its cure, before the plain verdict.
        const which = graphicsFault(g);
        if (which === 'no-gpu') return cause('graphics', 'DIAG_GRAPHICS_NO_GPU', { driver: g.driver, reason: g.reason }, 'screen');
        if (which === 'no-right') return cause('graphics', 'DIAG_GRAPHICS_NO_RIGHT', { reason: g.reason }, 'screen');
        if (which === 'mesa') {
          const parts = Object.keys(g.mesa.versions).map(function (k) { return k + ' ' + g.mesa.versions[k]; }).join(', ');
          return cause('graphics', 'DIAG_GRAPHICS_MESA', { reason: g.reason, parts: parts }, 'screen');
        }
        return cause('graphics', 'DIAG_GRAPHICS_BROKEN', { reason: g.reason }, 'screen');
      }
      if (g.x && g.x.state === 'software') return note('graphics', 'DIAG_GRAPHICS_X_SOFTWARE', { detail: g.x.detail });
      if (g.applies && g.ok && g.software) return note('graphics', 'DIAG_GRAPHICS_SOFTWARE', { renderer: g.renderer });
      return g.applies && g.ok ? ok('graphics', 'DIAG_GRAPHICS_OK', { reason: g.reason }) : null;
    }
  },

  // ---- the meters show but do not move ---------------------------------
  {
    id: 'tap', symptoms: ['not-moving', 'remotes'],
    run(f) {
      const audio = f.status.sheet && f.status.sheet.audio;
      if (!audio) return null;
      return audio.tapInChain ? ok('tap', 'DIAG_TAP_IN') : cause('tap', 'DIAG_TAP_OUT');
    }
  },
  {
    id: 'measured', symptoms: ['not-moving', 'remotes'],
    run(f) {
      if (!playing(f)) return null;
      return f.status.measured ? ok('measured', 'DIAG_MEASURED')
        : cause('measured', 'DIAG_NOT_MEASURED', { service: (f.status.channel && f.status.channel.service) || '?' });
    }
  },

  // ---- touch and the controls ------------------------------------------
  {
    id: 'interactive', symptoms: ['touch'],
    run(f) {
      const mode = f.status.interactive;
      if (mode === 'off') return cause('interactive', 'DIAG_INTERACTIVE_OFF', {}, 'system');
      if (mode === 'theme') return note('interactive', 'DIAG_INTERACTIVE_THEME', {}, 'system');
      return mode === 'on' ? ok('interactive', 'DIAG_INTERACTIVE_ON') : null;
    }
  },
  {
    id: 'pointing', symptoms: ['touch'],
    run(f) {
      const inputs = f.screen && f.screen.probe && f.screen.probe.inputs;
      if (!inputs) return null;
      const found = (inputs.touch || []).concat(inputs.mice || []);
      return found.length ? ok('pointing', 'DIAG_POINTING', { names: found.map((d) => d.name).join(', ') }) : cause('pointing', 'DIAG_NO_POINTING');
    }
  },
  {
    id: 'touch-map', symptoms: ['touch'],
    run(f) {
      const sc = f.screen;
      if (!sc || !sc.touch) return null;
      if (!sc.free) return note('touch-map', 'DIAG_TOUCH_UNDER_KIOSK');
      const c = sc.touch.calibration || {};
      if (c.state === 'failed') return cause('touch-map', 'DIAG_CALIBRATION_FAILED', {}, 'screen');
      return note('touch-map', sc.touch.mapping === 'auto' ? 'DIAG_TOUCH_MAP_AUTO' : 'DIAG_TOUCH_MAP_SET', { mapping: sc.touch.mapping }, 'screen');
    }
  },
  {
    id: 'channel', symptoms: ['touch', 'browse'],
    run(f) {
      if (!f.status.running || !f.status.channel) return null;
      return f.status.channel.clients > 0 ? ok('channel', 'DIAG_CHANNEL_UP') : cause('channel', 'DIAG_CHANNEL_DOWN');
    }
  },

  // ---- the picture on the screen ---------------------------------------
  {
    id: 'panel-power', symptoms: ['screen', 'no-meters', 'face'],
    run(f) {
      const p = f.power;
      if (!p || !p.display) return null;
      if (p.power !== 'off') {
        // On, and dimmed while the player stands still: as set, worth knowing.
        const i = p.idle;
        if (i && i.on && i.dimmed) return note('panel-power', 'DIAG_PANEL_DIMMED', { level: i.level === null ? '-' : i.level, max: p.maxBrightness === null ? '?' : p.maxBrightness, bright: i.bright === null ? '-' : i.bright }, 'screen');
        return null;
      }
      return p.by === 'dark' ? cause('panel-power', 'DIAG_PANEL_DARK', {}, 'screen')
        : cause('panel-power', 'DIAG_PANEL_OFF', { by: p.by || '-' }, 'screen');
    }
  },
  {
    id: 'backdrop', symptoms: ['screen', 'artwork'],
    run(f) {
      const d = f.display;
      const theme = sizeOf(f.status.themeSize);
      const screen = sizeOf(f.status.sheet && f.status.sheet.screen && f.status.sheet.screen.size);
      if (!d || !theme || !screen) return null;
      // Fitted, a theme of another shape leaves bars; as it is, a smaller one leaves a band.
      const bare = d.fit ? Math.abs(theme.w * screen.h - theme.h * screen.w) > screen.w * screen.h / 100
        : theme.w < screen.w || theme.h < screen.h;
      if (!bare) return null;
      return d.backdrop ? ok('backdrop', 'DIAG_BACKDROP_ON')
        : note('backdrop', 'DIAG_BACKDROP_OFF', { theme: f.status.themeSize, screen: f.status.sheet.screen.size }, 'artwork');
    }
  },
  {
    id: 'whose', symptoms: ['screen'],
    run(f) {
      if (!f.screen) return null;
      return f.screen.free ? ok('whose', 'DIAG_SCREEN_GLASS') : note('whose', 'DIAG_SCREEN_KIOSK', {}, 'screen');
    }
  },
  {
    id: 'rotation', symptoms: ['screen', 'touch'],
    run(f) {
      const sc = f.screen;
      if (!sc || !sc.free || !sc.probe || !sc.probe.suggestion) return null;
      const suggested = sc.probe.suggestion.rotation || 0;
      const rotation = sc.rotation || 0;
      if (rotation === suggested) return ok('rotation', 'DIAG_ROTATION_AS_SUGGESTED', { rotation });
      const fill = { rotation, suggested, panel: sc.probe.suggestion.panel || '?' };
      return rotation === 0 ? cause('rotation', 'DIAG_ROTATION_PORTRAIT', fill, 'screen') : note('rotation', 'DIAG_ROTATION_DIFFERS', fill, 'screen');
    }
  },
  {
    id: 'size', symptoms: ['screen', 'slow'],
    run(f) {
      const screen = f.status.sheet && f.status.sheet.screen && f.status.sheet.screen.size;
      const theme = f.status.themeSize;
      if (!screen || !theme || screen === theme) return null;
      return note('size', 'DIAG_THEME_SIZE', { theme, screen }, 'artwork');
    }
  },

  // ---- pictures --------------------------------------------------------
  {
    id: 'fanart', symptoms: ['artwork', 'slow'],
    run(f) {
      const a = f.status.artwork;
      if (!a) return null;
      if (f.symptom === 'slow') return a.enabled ? note('fanart', 'DIAG_FANART_COSTS', {}, 'artwork') : null;
      return a.enabled ? ok('fanart', 'DIAG_FANART_ON') : cause('fanart', 'DIAG_FANART_OFF', {}, 'artwork');
    }
  },
  {
    id: 'places', symptoms: ['artwork'],
    run() { return note('places', 'DIAG_ARTWORK_PLACES'); }
  },

  // ---- remote displays, the Face, Anymote ------------------------------
  {
    id: 'serving', symptoms: ['remotes'],
    run(f) {
      const r = f.status.remotes;
      if (!r) return null;
      if (!r.enabled) return note('serving', 'DIAG_SERVING_OFF', {}, 'remotes');
      if (!r.serving || r.problem) return cause('serving', 'DIAG_SERVING_DOWN', { problem: r.problem || '-' }, 'remotes');
      return ok('serving', 'DIAG_SERVING', { frames: r.ports.frames, channel: r.ports.channel });
    }
  },
  {
    id: 'receiving', symptoms: ['remotes'],
    run(f) {
      const r = f.status.remotes;
      if (!r || !r.enabled || !r.serving) return null;
      if (r.connected === 0) return note('receiving', 'DIAG_NO_REMOTES', {}, 'remotes');
      return r.receiving < r.connected ? cause('receiving', 'DIAG_NOT_RECEIVING', { connected: r.connected, receiving: r.receiving, port: r.ports.frames }, 'remotes')
        : ok('receiving', 'DIAG_RECEIVING', { connected: r.connected });
    }
  },
  {
    id: 'face', symptoms: ['remotes'],
    run(f) {
      const face = f.status.face;
      if (!face || !face.pages) return null;
      if (face.frames) return ok('face', 'DIAG_FACE_FRAMES', { pages: face.pages });
      return playing(f) && f.status.measured ? cause('face', 'DIAG_FACE_NO_FRAMES') : note('face', 'DIAG_FACE_RESTS');
    }
  },

  // ---- it is slow ------------------------------------------------------
  {
    id: 'governed', symptoms: ['slow', 'restarts'],
    run(f) {
      const p = f.status.performance;
      const rate = f.status.showing && f.status.showing.rate;
      if (!p || !p.values || !rate || !f.status.running) return null;
      return rate < p.values.frameRate ? cause('governed', 'DIAG_GOVERNED', { rate, set: p.values.frameRate }, 'system') : null;
    }
  },
  {
    id: 'rate', symptoms: ['slow'],
    run(f) {
      const p = f.status.performance;
      if (!p || !p.values || !p.profiles || !p.profiles[p.auto]) return null;
      const suits = p.profiles[p.auto].frameRate;
      const board = (p.board && p.board.model) || '?';
      return p.values.frameRate > suits ? note('rate', 'DIAG_RATE_ABOVE_BOARD', { rate: p.values.frameRate, suits, board }, 'system')
        : ok('rate', 'DIAG_RATE_SUITS', { rate: p.values.frameRate, board });
    }
  },

  // ---- glass-evo: the face, the look panel, the forecast ----------------
  // The facts are the status sheet's glass-evo section (sheetfacts.evo) and
  // the theme's own fonts; a sheet without them, a Glass before 0.9.6 or a
  // read that failed, says nothing here.
  {
    id: 'evo-component', symptoms: ['face', 'look', 'forecast', 'browse', 'remotes', 'other'],
    run(f) {
      const e = f.status.evo;
      if (!e) return null;
      if (!e.component) return cause('evo-component', 'DIAG_EVO_NOT_INSTALLED', {}, 'system');
      if (e.outdated) return cause('evo-component', 'DIAG_EVO_OUTDATED', { version: e.component.version, least: e.least || '?' }, 'system');
      if (!e.component.available) return cause('evo-component', 'DIAG_EVO_NO_BINARY', { version: e.component.version, arch: f.status.arch || '?' }, 'system');
      return ok('evo-component', 'DIAG_EVO_COMPONENT', { version: e.component.version });
    }
  },
  {
    id: 'evo-owner', symptoms: ['face', 'forecast'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component) return null;
      return e.owner === 'glass-evo' ? ok('evo-owner', 'DIAG_EVO_OWNS') : cause('evo-owner', 'DIAG_EVO_KIOSK_OWNS', {}, 'screen');
    }
  },
  {
    // The display that runs where glass-evo owns the screen: started after
    // the component's install, and with the component's binary.
    id: 'evo-display', symptoms: ['face', 'look', 'forecast', 'restarts', 'other'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || e.owner !== 'glass-evo' || !e.displayStartedAt) return null;
      if (e.displayOlder) return cause('evo-display', 'DIAG_EVO_DISPLAY_OLDER', { version: e.component.version }, 'screen');
      if (!e.displayBinary) return cause('evo-display', 'DIAG_EVO_GLASS_BINARY', {}, 'screen');
      return ok('evo-display', 'DIAG_EVO_DISPLAY_FACE', { version: e.component.version });
    }
  },
  {
    // The module the views and the look panel draw with: the component's,
    // present, and in this page the installed one.
    id: 'evo-module', symptoms: ['look', 'remotes', 'browse'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || !e.views) return null;
      if (e.views.mode === 'face' && !e.views.has) return cause('evo-module', 'DIAG_EVO_NO_MODULE', { version: e.component.version }, 'system');
      if (!e.views.face) return note('evo-module', 'DIAG_EVO_VIEWS_THEME_ALONE', {}, 'screen');
      const page = f.page && f.page.module;
      if (page && page !== e.component.version) return cause('evo-module', 'DIAG_EVO_MODULE_STALE', { page, installed: e.component.version });
      return ok('evo-module', 'DIAG_EVO_MODULE', { version: e.views.version || e.component.version });
    }
  },
  {
    id: 'evo-look', symptoms: ['face', 'look'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || !e.look) return null;
      const l = e.look;
      if (l.source === 'missing') return cause('evo-look', 'DIAG_EVO_LOOK_MISSING', { name: l.name }, 'screen');
      if (l.themeBrings) return note('evo-look', 'DIAG_EVO_THEME_LOOK', { folder: l.themeFolder || '?' }, 'screen');
      return l.name ? ok('evo-look', 'DIAG_EVO_LOOK', { name: l.name }) : ok('evo-look', 'DIAG_EVO_LOOK_BUILTIN');
    }
  },
  {
    id: 'evo-picture', symptoms: ['face', 'look'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || !e.picture) return null;
      return e.picture.found ? ok('evo-picture', 'DIAG_EVO_PICTURE', { name: e.picture.name })
        : cause('evo-picture', 'DIAG_EVO_PICTURE_MISSING', { name: e.picture.name }, 'screen');
    }
  },
  {
    id: 'evo-skies', symptoms: ['face', 'look', 'forecast'],
    run(f) {
      const e = f.status.evo;
      const names = e && e.look && e.look.unknownSkies;
      return names && names.length ? note('evo-skies', 'DIAG_EVO_SKIES_UNKNOWN', { names: names.join(', ') }) : null;
    }
  },
  {
    // The theme on show names files that are not there: a cause where the
    // display cannot do without them, a note where it does (a field's
    // font, a knob's picture).
    id: 'theme-files', symptoms: ['no-meters', 'screen', 'remotes', 'other'],
    run(f) {
      const files = f.status.themeFiles;
      if (!Array.isArray(files)) return null;
      // A sheet from 0.9.6 to 0.9.13 listed the fonts alone, found or not, without a state.
      const stateOf = (x) => x.state || (x.found ? 'found' : /\.font$/.test(x.key) ? 'optional' : 'missing');
      const list = (state) => files.filter((x) => stateOf(x) === state).map((x) => x.key + ' = ' + x.file).join(', ');
      const theme = f.status.activeTheme || '?';
      if (list('missing')) return cause('theme-files', 'DIAG_THEME_FILE_MISSING', { theme, files: list('missing') }, 'themes');
      if (list('optional')) return note('theme-files', 'DIAG_THEME_FILE_OPTIONAL', { theme, files: list('optional') }, 'themes');
      return null;
    }
  },
  {
    id: 'forecast-place', symptoms: ['face', 'forecast'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || !e.weather) return null;
      return e.weather.on ? ok('forecast-place', 'DIAG_FORECAST_PLACE') : cause('forecast-place', 'DIAG_FORECAST_NO_PLACE', {}, 'screen');
    }
  },
  {
    // The reading: there, fresh (the player asks every hour; three hours is
    // stale), and the last request's error when it had one.
    id: 'forecast-reading', symptoms: ['face', 'forecast'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || !e.weather || !e.weather.on) return null;
      const w = e.weather;
      const error = w.error || '-';
      if (w.readingAgeS === null) return cause('forecast-reading', 'DIAG_FORECAST_NO_READING', { error });
      const minutes = Math.round(w.readingAgeS / 60);
      if (w.readingAgeS > 3 * 3600) return cause('forecast-reading', 'DIAG_FORECAST_STALE', { minutes, error });
      return w.error ? note('forecast-reading', 'DIAG_FORECAST_ERROR', { minutes, error: w.error }) : ok('forecast-reading', 'DIAG_FORECAST_FRESH', { minutes });
    }
  },
  {
    id: 'idle-wait', symptoms: ['face'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || e.idleWait !== 'persist') return null;
      return e.persistS === 0 ? note('idle-wait', 'DIAG_IDLE_WAIT_NO_PERSIST', {}, 'screen')
        : note('idle-wait', 'DIAG_IDLE_WAIT_PERSIST', { seconds: e.persistS === null ? '?' : e.persistS }, 'screen');
    }
  },
  {
    id: 'skies-motion', symptoms: ['slow', 'face'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || e.owner !== 'glass-evo' || !e.weather || !e.weather.on) return null;
      return e.motion && e.smallBoard ? note('skies-motion', 'DIAG_SKIES_MOTION_SMALL', {}, 'screen') : null;
    }
  },

  // ---- the buttons, the last install, what there is to browse -----------
  {
    // The look's buttons: off takes the bar and its sheet off the face, so
    // nothing on it answers a touch and the queue, the browser and search
    // cannot be opened. The cause where touch or browsing is the complaint,
    // worth knowing elsewhere.
    id: 'buttons', symptoms: ['touch', 'face', 'look', 'remotes', 'browse'],
    run(f) {
      const e = f.status.evo;
      if (!e || !e.component || typeof e.buttons !== 'boolean') return null;
      if (e.buttons) return ok('buttons', e.buttonsIdle === 'leave' ? 'DIAG_BUTTONS_SHOWN_IDLE_LEAVES' : 'DIAG_BUTTONS_SHOWN');
      const by = f.symptom === 'touch' || f.symptom === 'browse' ? cause : note;
      return by('buttons', 'DIAG_BUTTONS_HIDDEN', {}, 'screen');
    }
  },
  {
    // The last install that ended, an upgrade, a rollback, a glass-evo
    // install or a return to the stable release: refused for the pair when
    // one zip of the two was given alone, or failed in its own words. One
    // that went through says nothing here; the release check has it.
    id: 'install-job', symptoms: SYMPTOMS,
    run(f) {
      const j = f.job;
      if (!j || j.state !== 'failed' || !j.error) return null;
      const fill = { name: j.name || '?', message: j.error.message || j.error.error || '-' };
      if (j.error.error === 'needs-evo' || j.error.error === 'needs-glass') return cause('install-job', 'DIAG_INSTALL_NEEDS_PAIR', fill, 'system');
      return note('install-job', 'DIAG_INSTALL_FAILED', fill, 'system');
    }
  },
  {
    // A release zip brought by hand that could not go in alone, kept on
    // the player for the other zip of the pair: a Glass waiting for a
    // glass-evo, a glass-evo waiting for a Glass. Worth knowing under
    // every symptom, since the upgrade the user meant has not happened.
    id: 'held-zip', symptoms: SYMPTOMS,
    run(f) {
      const h = f.held;
      if (!h) return null;
      if (h.glass) return note('held-zip', 'DIAG_HELD_GLASS', { version: h.glass.version, needs: h.glass.needs || '-' }, 'system');
      if (h.evo) return note('held-zip', 'DIAG_HELD_EVO', { version: h.evo.version, needs: h.evo.needs || '-' }, 'system');
      return null;
    }
  },
  {
    // What the player offers to browse: the sources of its own Browse page,
    // which the face lists as tiles. None, and the browser is empty for the
    // player's own reason, not Glass's.
    id: 'sources', symptoms: ['browse'],
    run(f) {
      const b = f.browse;
      if (!b || typeof b.count !== 'number') return null;
      return b.count ? ok('sources', 'DIAG_SOURCES', { count: b.count, names: (b.names || []).join(', ') }) : cause('sources', 'DIAG_NO_SOURCES');
    }
  },
  {
    // A source that writes web markup into its names, for the player's
    // classic interface to render: Glass clears it where the names enter,
    // so the lists and the theme show the words alone. Worth knowing when
    // a name looks odd, not a cause.
    id: 'markup', symptoms: ['browse', 'look', 'other'],
    run(f) {
      const m = f.markup;
      if (!m || !m.count) return null;
      return note('markup', 'DIAG_MARKUP_CLEARED', { count: m.count, services: (m.services || []).join(', ') || '-' });
    }
  },
  {
    // The theme on show was picked by an edition tag rule for what plays,
    // from the album name, the folder name or the source: worth knowing
    // when the theme is not the one chosen on the Themes tab.
    id: 'theme-rule', symptoms: ['look', 'other'],
    run(f) {
      const r = f.themeRule;
      if (!r || !r.folder) return null;
      const by = { album: 'the album name', folder: 'the folder name', source: 'the source' }[r.by] || r.by || '-';
      return note('theme-rule', 'DIAG_THEME_RULE', { folder: r.folder, tag: r.tag || '-', by: by, home: r.home || '-' }, 'themes');
    }
  }
];

// The findings for a symptom: likely causes first, then what is worth
// knowing, then what was checked and found right; and whether any cause
// was found. A check that throws on a fact it did not expect says nothing.
function diagnose(symptom, facts) {
  if (SYMPTOMS.indexOf(symptom) === -1) throw new Error('unknown symptom');
  const f = Object.assign({ status: {}, screen: null, update: null, log: [], now: Date.now() }, facts, { symptom });
  const findings = [];
  CHECKS.forEach(function (check) {
    if (check.symptoms.indexOf(symptom) === -1) return;
    let found = null;
    try { found = check.run(f); } catch (e) { found = null; }
    if (found) findings.push(found);
  });
  const order = { cause: 0, note: 1, ok: 2 };
  findings.sort((a, b) => order[a.kind] - order[b.kind]);
  return { symptom, found: findings.some((x) => x.kind === 'cause'), findings };
}

module.exports = { SYMPTOMS, CHECKS, diagnose, lineTime };

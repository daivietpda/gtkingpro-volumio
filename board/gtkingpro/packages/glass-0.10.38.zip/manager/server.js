'use strict';
// The Glass Manager: a small web application the plugin serves on its own
// port, for everything that manages the display rather than operates it.
// Installed themes with previews drawn by the display, the catalog and its
// installs, uploads, the meter rotation, artwork, backups and a status page.
//
// The server knows the plugin through a narrow interface (see index.js,
// "The manager's view of the plugin") and the file trees through the paths
// that interface names. It holds no Volumio state of its own.

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');
const express = require('express');

const { Zip, ZipError, unitsOf, extractUnit, safeFolderName } = require('./zip');
const { MAX_FONT_BYTES } = require('./fonts');
const { trackFileFor } = require('./trackfile');
const logging = require('./logging');
const { Catalog, CatalogError } = require('./catalog');
const { Previews } = require('./previews');
const { Updater, UpdateError, compareVersions, examineGlassZip, MAX_ZIP_BYTES } = require('./update');
const stable = require('./stable');
const remotebehind = require('./remotebehind');
const sheetfacts = require('./sheetfacts');
const backgrounds = require('./backgrounds');
const { Component, ComponentError, leastOf, pair, manifestFactsOf } = require('./component');
const { Held } = require('./held');
const pairing = require('./pairing');
const { Shelf, MAX_ARCHIVE_BYTES: MAX_SHELF_ARCHIVE } = require('./shelf');
const views = require('./views');
const picture = require('./picture');
const queue = require('./queue');
const { zipDirectory } = require('./zipwrite');
const tailor = require('./tailor');
const { SYMPTOMS, diagnose } = require('./diagnose');
const about = require('./about');

// What a release's zip says of itself: its package, and the three files
// its settings start from. One that is missing is left out.
async function releaseTexts(file) {
  const names = { package: 'package.json', config: 'config.json', meter: 'config/meter.txt.tmpl', spectrum: 'config/spectrum.txt.tmpl' };
  const texts = {};
  const zip = await Zip.open(file);
  try {
    for (const key of Object.keys(names)) {
      const entry = zip.entries.find(function (e) { return e.isRegular && e.name === names[key]; });
      if (entry && entry.size <= 1024 * 1024) texts[key] = (await zip.read(entry)).toString('utf8');
    }
  } finally {
    await zip.close();
  }
  return texts;
}
const { Capture, CaptureError } = require('./capture');

const MAX_BACKUP_UPLOAD_BYTES = 32 * 1024 * 1024;
const MAX_BACKUP_FILE_BYTES = 4 * 1024 * 1024;
const BACKUP_FILES = ['manifest.json', 'config.json', 'peppymeter_config.txt', 'spectrum_config.txt'];

const DEFAULT_PORT = 5582;
// Where Volumio's submitter keeps the system log it could not send.
const KEPT_SYSTEM_LOG = '/var/tmp/logondemand';
const MAX_TRACK_FILE_BYTES = 32 * 1024 * 1024;
const MAX_UPLOAD_BYTES = 512 * 1024 * 1024;
const CATALOG_INDEX_MAX_AGE_MS = 10 * 60 * 1000;
const JOBS_KEPT = 50;
const METER_NAME = /^[^/\\\0]{1,128}$/;
const SIZE_PREFIX = /^(\d{3,4})x(\d{3,4})/;

class Manager {
  constructor(plugin) {
    this.plugin = plugin;
    this.logger = plugin.logger;
    this.app = null;
    this.server = null;
    this.port = DEFAULT_PORT;
    this.jobs = [];
    this.jobSeq = 0;
    this.lock = Promise.resolve();
    const paths = plugin.managerPaths();
    this.paths = paths;
    this.catalog = new Catalog({ dir: path.join(paths.dataDir, 'catalog'), logger: this.logger });
    this.previews = new Previews({
      dir: path.join(paths.dataDir, 'previews'),
      launcher: paths.launcher,
      env: function () { return plugin.launchEnv(); },
      version: paths.version,
      logger: this.logger,
      uid: 1000,
      gid: 1000
    });
    this.updater = new Updater({
      dir: path.join(paths.dataDir, 'upgrade'),
      version: paths.version,
      pluginPath: paths.pluginPath,
      configDir: paths.configDir,
      dataDir: paths.dataDir,
      plugin: plugin,
      test: function () { return plugin.testReleases(); },
      logger: this.logger
    });
    let packageText = '';
    try { packageText = fs.readFileSync(path.join(paths.pluginPath, 'package.json'), 'utf8'); } catch (e) { /* no least named */ }
    this.component = new Component({
      dir: paths.evoDir,
      stateDir: path.join(paths.dataDir, 'evo-state'),
      glass: paths.version,
      least: leastOf(packageText),
      arch: function () { return plugin.volumioArch(); },
      test: function () { return plugin.testReleases(); },
      logger: this.logger
    });
    // A release zip brought by hand that cannot go in alone, kept for the
    // other zip of the pair.
    this.held = new Held({ dir: path.join(paths.dataDir, 'held'), logger: this.logger });
    this.shelf = new Shelf({
      dir: path.join(paths.dataDir, 'shelf'),
      ceilingMb: function () { return typeof plugin.shelfCeilingMb === 'function' ? plugin.shelfCeilingMb() : undefined; },
      logger: this.logger
    });
    this.capture = new Capture({
      file: path.join(paths.dataDir, 'capture.json'),
      now: Date.now,
      read: (file) => fs.readFileSync(file, 'utf8'),
      write: (file, text) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text); },
      remove: (file) => fs.unlinkSync(file),
      logSettings: () => plugin.logSettings(),
      setLogSettings: (settings) => plugin.setLogSettings(settings),
      relaunch: () => plugin.relaunchDisplay(),
      sendLog: (description) => plugin.sendSystemLog(description)
    });
  }

  // The port the manager listens on, and where it is reached from a browser.
  url() {
    const host = this.plugin.managerHost();
    return 'http://' + host + ':' + this.port + '/';
  }

  async start(port) {
    const self = this;
    self.port = parseInt(port, 10) || DEFAULT_PORT;
    await self.catalog.init();
    await self.previews.init();
    await self.updater.init();
    await self.component.init();
    try {
      await self.held.init();
      await self.pruneHeld();
    } catch (e) { self.logger.warn('glass: manager: the kept zips not read: ' + (e && e.message ? e.message : e)); }
    // A capture the backend went down under goes on, or ends if its time passed.
    try {
      if (self.capture.resume().state !== 'idle') self.logger.info('glass: manager: a report\'s capture goes on after the restart');
    } catch (e) { self.logger.warn('glass: manager: capture not resumed: ' + (e && e.message ? e.message : e)); }
    const app = express();
    app.disable('x-powered-by');
    app.use(express.json({ limit: '1mb' }));
    app.use(function (req, res, next) {
      res.set('Cache-Control', 'no-cache');
      next();
    });
    self.routes(app);
    app.use(function (err, req, res, next) { // eslint-disable-line no-unused-vars
      self.logger.error('glass: manager ' + req.method + ' ' + req.path + ': ' + (err && err.message ? err.message : err));
      if (res.headersSent) return;
      res.status(err && err.status ? err.status : 500).json(failure(err));
    });
    self.app = app;
    await new Promise(function (resolve, reject) {
      const server = app.listen(self.port, function () {
        self.server = server;
        resolve();
      });
      server.on('error', reject);
    });
    self.logger.info('glass: manager listening on port ' + self.port);
    // A look at the latest release a minute after start and once a day after.
    self.scheduleCheck(60000);
  }

  scheduleCheck(delayMs) {
    const self = this;
    if (self.checkTimer) clearTimeout(self.checkTimer);
    self.checkTimer = setTimeout(function () {
      self.checkTimer = null;
      if (!self.server) return;
      self.updater.check(false).then(function (view) {
        if (view.available) self.logger.info('glass: manager: Glass ' + view.latest.version + ' is available (running ' + view.current + ')');
      }, function (e) {
        self.logger.warn('glass: manager: release check: ' + (e && e.message ? e.message : e));
      }).then(function () {
        if (self.server) self.scheduleCheck(24 * 60 * 60 * 1000);
      });
    }, delayMs);
    if (self.checkTimer.unref) self.checkTimer.unref();
  }

  async stop() {
    const server = this.server;
    this.server = null;
    if (this.checkTimer) {
      clearTimeout(this.checkTimer);
      this.checkTimer = null;
    }
    if (!server) return;
    await new Promise(function (resolve) {
      server.close(function () { resolve(); });
      // Keep-alive connections would hold the port; the plugin is stopping.
      if (typeof server.closeAllConnections === 'function') server.closeAllConnections();
    });
    this.logger.info('glass: manager stopped');
  }

  // Work on the theme trees runs one job at a time.
  exclusive(fn) {
    const run = this.lock.then(fn, fn);
    this.lock = run.then(function () { }, function () { });
    return run;
  }

  // ---- routes ----------------------------------------------------------

  routes(app) {
    const self = this;
    const page = path.join(__dirname, 'manage.html');
    const wrap = function (fn) {
      return function (req, res, next) {
        Promise.resolve().then(function () { return fn(req, res); }).catch(next);
      };
    };

    app.get(['/', '/manage'], function (req, res) {
      res.sendFile(page);
    });

    app.get('/about/glass-phoenix.png', function (req, res) {
      res.sendFile(path.join(__dirname, 'glass-phoenix.png'), { maxAge: 86400000 });
    });

    app.get('/api/about/qr/:name', wrap(async function (req, res) {
      const svg = await about.qrSvg(req.params.name);
      if (!svg) return res.status(404).end();
      res.type('image/svg+xml').send(svg);
    }));

    app.get('/api/i18n', function (req, res) {
      const lang = String(req.query.lang || self.plugin.managerLanguage() || 'en').replace(/[^a-z]/gi, '').slice(0, 5) || 'en';
      res.json({ lang: lang, strings: self.plugin.managerStrings(lang) });
    });

    app.get('/api/status', wrap(async function (req, res) {
      res.json(await self.status());
    }));

    // The guided diagnosis: the symptoms it knows, and for one of them
    // what the checks find in the facts the Manager has at hand.
    app.get('/api/diagnose', function (req, res) {
      res.json({ symptoms: SYMPTOMS });
    });
    // `page` is what the page says of itself: the version of glass-evo's
    // module it drew the likeness with, for the check against the installed.
    const facts = async function (page) {
      const safe = function (fn, fallback) { try { return fn(); } catch (e) { return fallback; } };
      return {
        now: Date.now(),
        status: await self.status(),
        screen: safe(() => self.plugin.screenSettings(), null),
        power: safe(() => self.plugin.screenPower(), null),
        display: safe(() => self.plugin.displayPlacement(), null),
        update: safe(() => self.updater.view(), null),
        log: safe(() => self.plugin.recentLog(300).lines, []),
        job: self.lastInstallJob(),
        held: self.held.summary(),
        browse: safe(() => self.plugin.browseSourcesFact(), null),
        markup: safe(() => self.plugin.markupFact(), null),
        themeRule: safe(() => self.plugin.themeRuleFact(), null),
        page: { module: page && typeof page.module === 'string' ? page.module.slice(0, 32) : null }
      };
    };
    app.post('/api/diagnose', wrap(async function (req, res) {
      const symptom = String((req.body && req.body.symptom) || '');
      if (SYMPTOMS.indexOf(symptom) === -1) return res.status(400).json({ error: 'bad-symptom' });
      res.json(diagnose(symptom, await facts(req.body && req.body.page)));
    }));

    // The capture behind a report: Glass logs in full while the problem is
    // reproduced, then the player's system log goes out through Volumio's
    // own submitter and the report comes back with its link. The level is
    // put back here, whatever the page does.
    const captured = function (res, fn) {
      return Promise.resolve().then(fn).then(function (out) { res.json(out); }, function (e) {
        if (e instanceof CaptureError) return res.status(409).json({ error: e.code });
        throw e;
      });
    };
    // A time as the journal writes it, by the player's clock, to find the
    // capture's window in the system log.
    const journalStamp = function (ms) {
      const d = new Date(ms);
      const two = (n) => String(n).padStart(2, '0');
      return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()] + ' ' + two(d.getDate()) + ' ' + two(d.getHours()) + ':' + two(d.getMinutes()) + ':' + two(d.getSeconds());
    };
    const stamped = function (view) {
      return view.startedAt ? Object.assign({}, view, { from: journalStamp(view.startedAt), to: journalStamp(view.endedAt || view.until) }) : view;
    };
    app.get('/api/diagnose/capture', function (req, res) {
      res.json(stamped(self.capture.view()));
    });
    app.post('/api/diagnose/capture', wrap(async function (req, res) {
      const symptom = String((req.body && req.body.symptom) || '');
      if (SYMPTOMS.indexOf(symptom) === -1) return res.status(400).json({ error: 'bad-symptom' });
      const diagnosis = diagnose(symptom, await facts());
      return captured(res, () => stamped(self.capture.start(symptom, diagnosis)));
    }));
    app.post('/api/diagnose/capture/finish', wrap(function (req, res) {
      return captured(res, async function () {
        const report = stamped(await self.capture.finish(self.paths.version, req.body && req.body.text));
        if (report.log.error) {
          // The submitter keeps a log it could not send; offered only when it is this capture's.
          let kept = false;
          try { kept = fs.statSync(KEPT_SYSTEM_LOG).mtimeMs >= report.endedAt - 5000; } catch (e) { kept = false; }
          report.log.kept = kept;
        }
        return report;
      });
    }));
    app.post('/api/diagnose/capture/cancel', wrap(function (req, res) {
      return captured(res, () => self.capture.cancel());
    }));
    app.get('/api/diagnose/log', function (req, res) {
      if (!fs.existsSync(KEPT_SYSTEM_LOG)) return res.status(404).json({ error: 'no-log' });
      const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
      res.download(KEPT_SYSTEM_LOG, 'volumio-log-' + os.hostname() + '-' + stamp + '.txt');
    });

    // Installed themes.
    app.get('/api/themes', wrap(async function (req, res) {
      res.json(await self.themes());
    }));

    app.post('/api/themes/:folder/activate', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      const result = await self.exclusive(function () { return self.plugin.activateTheme(folder); });
      if (result.error) return res.status(400).json({ error: result.error });
      res.json({ ok: true, active: folder, changed: result.changed !== false });
    }));

    app.delete('/api/themes/:folder', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      const result = await self.exclusive(async function () {
        const outcome = self.plugin.removeTheme(folder);
        if (!outcome.error) {
          await self.previews.drop(folder);
          await self.catalog.forgetFolder('templates', folder);
          await self.catalog.forgetFolder('templates_spectrum', folder);
        }
        return outcome;
      });
      if (result.error) return res.status(400).json({ error: result.error });
      res.json({ ok: true, switchedTo: result.switchedTo || null });
    }));

    // The cutter: a copy of the theme at another size, installed beside it.
    app.post('/api/themes/:folder/tailor', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      if (!fs.existsSync(path.join(self.paths.meterBase, folder, 'meters.txt'))) return res.status(404).json({ error: 'not-found' });
      const body = req.body || {};
      const size = tailor.parseSize(String(body.width || '') + 'x' + String(body.height || ''));
      if (!size) return res.status(400).json({ error: 'bad-size' });
      const job = self.newJob('tailor', folder + ' \u2192 ' + size.width + 'x' + size.height);
      self.runTailor(job, folder, size, body.stretch === true || body.stretch === 'true');
      res.status(202).json({ ok: true, job: job });
    }));

    // The packager: the theme as the catalogue takes it, with a preview,
    // as a zip the browser fetches when the job is done.
    app.post('/api/themes/:folder/package', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      if (!fs.existsSync(path.join(self.paths.meterBase, folder, 'meters.txt'))) return res.status(404).json({ error: 'not-found' });
      const settle = Math.min(30, Math.max(1, parseInt((req.body || {}).settle, 10) || 3));
      const job = self.newJob('package', folder);
      self.runPackage(job, folder, settle);
      res.status(202).json({ ok: true, job: job });
    }));

    app.get('/api/jobs/:id/file', function (req, res) {
      const job = self.jobs.find(function (j) { return String(j.id) === String(req.params.id); });
      if (!job || job.kind !== 'package' || job.state !== 'done' || !job.file || !fs.existsSync(job.file)) return res.status(404).json({ error: 'not-found' });
      res.setHeader('Content-Disposition', 'attachment; filename="' + path.basename(job.file).replace(/[^A-Za-z0-9 ._()+-]/g, '_') + '"');
      res.setHeader('Content-Type', 'application/zip');
      res.sendFile(job.file, { maxAge: 0 });
    });

    app.get('/api/themes/:folder/previews', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      res.json(await self.previewsOf(folder));
    }));

    app.post('/api/themes/:folder/render', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      const metersFile = path.join(self.paths.meterBase, folder, 'meters.txt');
      if (!fs.existsSync(metersFile)) return res.status(404).json({ error: 'not-found' });
      const force = !!(req.body && req.body.force);
      const wait = !!(req.body && req.body.wait);
      const job = self.previews.ensure(folder, metersFile, force);
      job.catch(function (e) {
        self.logger.warn('glass: manager preview of ' + folder + ': ' + e.message);
      });
      if (wait) {
        try {
          await job;
        } catch (e) {
          return res.status(500).json({ error: 'render-failed', message: e.message });
        }
      }
      res.json(await self.previewsOf(folder));
    }));

    app.get('/api/themes/:folder/preview/:meter', wrap(async function (req, res) {
      const folder = self.folderParam(req);
      const meter = String(req.params.meter || '');
      if (!METER_NAME.test(meter)) return res.status(400).json({ error: 'bad-meter' });
      const file = self.previews.file(folder, meter, req.query.thumb === '1');
      if (!fs.existsSync(file)) return res.status(404).json({ error: 'not-found' });
      res.type('png');
      res.sendFile(file, { maxAge: 0 });
    }));

    // The meter rotation of the active theme.
    app.get('/api/meter', function (req, res) {
      res.json(self.plugin.meterSelection());
    });

    app.post('/api/meter', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setMeterSelection(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.meterSelection()));
    }));

    // The catalog: the index fetched when there is none, or again when the
    // one kept is older than ten minutes (a 304 when it has not changed);
    // a failed refresh keeps the index kept.
    app.get('/api/catalog', wrap(async function (req, res) {
      if (self.catalog.stale(CATALOG_INDEX_MAX_AGE_MS)) {
        try {
          await self.catalog.refresh();
        } catch (e) {
          if (!self.catalog.index) return res.json(self.catalogView(e));
          self.logger.warn('glass: catalog: the index could not be refreshed, the one kept stands: ' + e.message);
        }
      }
      res.json(self.catalogView(null));
    }));

    app.post('/api/catalog/refresh', wrap(async function (req, res) {
      try {
        await self.catalog.refresh();
      } catch (e) {
        return res.status(502).json(self.catalogView(e));
      }
      res.json(self.catalogView(null));
    }));

    app.get('/api/catalog/thumb/:name', wrap(async function (req, res) {
      const name = String(req.params.name || '');
      if (!safeFolderName(name)) return res.status(400).json({ error: 'bad-name' });
      let file;
      try {
        file = await self.catalog.thumb(name);
      } catch (e) {
        return res.status(502).json(failure(e));
      }
      if (!file) return res.status(404).json({ error: 'not-found' });
      res.sendFile(file, { maxAge: 86400000 });
    }));

    app.post('/api/catalog/install', wrap(async function (req, res) {
      const name = String((req.body && req.body.name) || '');
      const entry = self.catalog.find(name);
      if (!entry) return res.status(404).json({ error: 'not-found' });
      const job = self.newJob('install', name);
      self.runInstall(job, entry);
      res.status(202).json({ ok: true, job: job });
    }));

    // A zip sent as the request body.
    app.post('/api/upload', wrap(async function (req, res) {
      const rawName = String(req.query.name || req.headers['x-file-name'] || 'upload.zip');
      const name = path.basename(rawName, path.extname(rawName)).replace(/[^A-Za-z0-9 ._()+-]/g, '_').slice(0, 96) || 'upload';
      if (!safeFolderName(name)) return res.status(400).json({ error: 'bad-name' });
      const file = path.join(self.catalog.downloadsDir, 'upload-' + Date.now() + '.zip');
      try {
        await self.receive(req, file, MAX_UPLOAD_BYTES);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      const job = self.newJob('upload', name);
      self.runUpload(job, file, name);
      res.status(202).json({ ok: true, job: job });
    }));

    app.get('/api/jobs', function (req, res) {
      res.json({ jobs: self.jobs.slice().reverse() });
    });

    app.get('/api/jobs/:id', function (req, res) {
      const job = self.jobs.find(function (j) { return String(j.id) === String(req.params.id); });
      if (!job) return res.status(404).json({ error: 'not-found' });
      res.json({ job: job });
    });

    // The old plugin's themes, and their removal.
    app.get('/api/legacy', function (req, res) {
      res.json(self.plugin.legacyThemes());
    });

    app.post('/api/legacy/wipe', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.wipeLegacyThemes(); });
      res.json(Object.assign(result, self.plugin.legacyThemes()));
    }));

    // Where the theme goes on the screen.
    app.get('/api/display', function (req, res) {
      res.json(self.plugin.displayPlacement());
    });

    app.post('/api/display', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setDisplayPlacement(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.displayPlacement()));
    }));

    // Artwork.
    app.get('/api/artwork', function (req, res) {
      res.json(self.plugin.artworkSettings());
    });

    app.post('/api/artwork', wrap(async function (req, res) {
      const result = self.plugin.setArtworkSettings(req.body || {});
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.artworkSettings()));
    }));

    app.get('/api/sharing', function (req, res) {
      res.json(self.plugin.sharingInfo());
    });

    app.post('/api/sharing', wrap(async function (req, res) {
      const result = self.plugin.setSharing((req.body || {}).shared);
      res.json(Object.assign({ ok: true, changed: !!result.changed }, self.plugin.sharingInfo()));
    }));

    // The screen: what draws the window, and the picture's turn.
    app.get('/api/screen', function (req, res) {
      res.json(self.plugin.screenSettings());
    });

    // The probe again, fresh, for the tab's "look again".
    app.get('/api/screen/probe', function (req, res) {
      res.json(self.plugin.screenProbe(true));
    });

    // The panel's power: its state; on, off, toggle, or a brightness.
    app.get('/api/screen/power', function (req, res) {
      res.json(self.plugin.screenPower());
    });

    app.post('/api/screen/power', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setScreenPower(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(result);
    }));

    // The touch mapping: as the panel reports, overrides, or calibrated.
    app.post('/api/screen/touch', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setTouchSettings(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.touchSettings()));
    }));

    // Calibrate: the display shows targets and answers with the matrix.
    app.post('/api/screen/calibrate', wrap(async function (req, res) {
      res.json(self.plugin.startCalibration());
    }));

    app.post('/api/screen', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setScreenSettings(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.screenSettings()));
    }));

    // The screen's owner: glass-evo takes the screen, or the kiosk gets it
    // back, through the plugins' own lifecycles, with the register kept.
    app.post('/api/screen/owner', wrap(async function (req, res) {
      const owner = String((req.body || {}).owner || '');
      const force = (req.body || {}).force === true;
      const result = await self.exclusive(function () { return self.plugin.setScreenOwner(owner, { force: force }); });
      if (result && result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, result, { screen: self.plugin.screenSettings() }));
    }));

    // The face's look: its settings in the display's configuration, the
    // face themes installed, and whether frost suits this board.
    app.get('/api/face', function (req, res) {
      res.json(self.plugin.faceSettings());
    });
    app.post('/api/face', function (req, res) {
      const body = req.body || {};
      const result = self.plugin.setFaceSettings(body.set, body.reset === true);
      if (result && result.error) return res.status(400).json(result);
      res.json(result);
    });

    // Interactive controls: as the theme says, on, or off.
    app.get('/api/touch', function (req, res) {
      res.json({ interactive: self.plugin.interactiveMode() });
    });

    app.post('/api/touch', wrap(async function (req, res) {
      const result = self.plugin.setInteractiveMode((req.body || {}).interactive);
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, result));
    }));

    // The Face tab: the feed behind it, the module and the page's script.
    app.get('/api/face/events', function (req, res) {
      if (!self.plugin.face) return res.status(503).json({ error: 'no-face' });
      self.plugin.face.attach(req, res);
    });
    app.get('/face/glass-face.wasm', function (req, res) {
      const file = path.join(self.paths.pluginPath, 'face', 'glass-face.wasm');
      if (!fs.existsSync(file)) return res.status(404).json({ error: 'no-module' });
      res.type('application/wasm');
      res.sendFile(file, { maxAge: 0 });
    });
    // glass-evo's module, Glass's pipeline with the face over it, from
    // the component where it carries one.
    app.get('/face/glass-evo-face.wasm', function (req, res) {
      const evo = self.plugin.evoComponent();
      if (!evo.installed || !evo.face) return res.status(404).json({ error: 'no-module' });
      res.type('application/wasm');
      res.sendFile(evo.face, { maxAge: 0 });
    });
    // Which module a page brings, and what goes with it: Glass's own, or
    // glass-evo's with the text of the face theme the settings name. The
    // user's choice of what the views show decides (`mode`: follow the
    // screen, the face wherever the component is here, or the theme alone).
    // A face theme's own files, the skies, for a page's table and the look
    // panel's likeness: the list for a theme by its name, and one file.
    app.get('/api/face/theme-files', function (req, res) {
      const found = self.plugin.faceThemeFilesOf(String((req.query || {}).name || ''));
      if (!found) return res.status(404).json({ error: 'not-found' });
      res.json(found);
    });
    app.get('/api/face/theme-file', function (req, res) {
      const file = self.plugin.faceThemePath(String((req.query || {}).name || ''), String((req.query || {}).file || ''));
      if (!file) return res.status(404).json({ error: 'not-found' });
      res.sendFile(file, { maxAge: 0 });
    });
    app.get('/api/face/module', function (req, res) {
      const m = self.plugin.faceModule();
      res.json({
        module: m.face ? 'glass-evo' : 'glass',
        url: m.face ? '/face/glass-evo-face.wasm?v=' + encodeURIComponent(m.version) : '/face/glass-face.wasm?v=' + encodeURIComponent(self.paths.version),
        mode: m.mode,
        has: m.has,
        theme: m.theme
      });
    });
    app.post('/api/face/views', wrap(async function (req, res) {
      const mode = String((req.body || {}).mode || '');
      if (views.MODES.indexOf(mode) === -1) return res.status(400).json({ error: 'bad-request', message: 'mode is one of ' + views.MODES.join(', ') });
      const result = self.plugin.setViewsMode(mode);
      const m = self.plugin.faceModule();
      res.json({ ok: true, changed: result.changed, mode: m.mode, has: m.has, face: m.face });
    }));
    app.get('/face/face-page.js', function (req, res) {
      res.sendFile(path.join(__dirname, 'face-page.js'), { maxAge: 0 });
    });
    // The look panel's model, which the page shares with its tests.
    // The report's forms (a post, an issue, a file), one script for the page and its tests.
    app.get('/diag/report.js', function (req, res) {
      res.sendFile(path.join(__dirname, 'report.js'), { maxAge: 0 });
    });
    app.get('/look/lookmodel.js', function (req, res) {
      res.sendFile(path.join(__dirname, 'lookmodel.js'), { maxAge: 0 });
    });
    // A tap or a drag on the Face tab's controls: the command a display
    // would send down the channel, run the same way.
    app.post('/api/face/command', wrap(async function (req, res) {
      const body = req.body || {};
      const name = String(body.name || '').slice(0, 32);
      if (!/^[a-z]+$/.test(name)) return res.status(400).json({ error: 'bad-command' });
      const message = { kind: 'command', name };
      if (body.value !== undefined && body.value !== null) message.value = body.value;
      // A command with an answer (browse, search) answers here with the
      // line a display would get down the channel; the page hands it to
      // its module as it hands the feed's lines.
      const answer = self.plugin.runCommand(message);
      if (answer && typeof answer.then === 'function') {
        let line = null;
        try { line = await answer; } catch (e) { line = null; }
        return res.json({ ok: true, name, line: line || null });
      }
      res.json({ ok: true, name });
    }));

    // A meter stepped to in a browser view: the player's own screen is
    // asked to show it too. `told` says whether a screen was there to ask.
    app.post('/api/face/meter', wrap(async function (req, res) {
      const meter = String((req.body || {}).meter || '');
      if (!meter || meter.length > 128 || /[\u0000-\u001f\[\]]/.test(meter)) return res.status(400).json({ error: 'bad-meter' });
      res.json({ ok: true, meter, told: self.plugin.showMeter(meter) });
    }));

    // The forecast for the face: the place chosen and the unit, the reading
    // held and the source to credit; places of a name to choose from; a
    // place set, the unit changed, or the forecast turned off.
    app.get('/api/weather', function (req, res) {
      res.json(self.plugin.weatherState());
    });
    app.get('/api/weather/search', wrap(async function (req, res) {
      const name = String(req.query.name || '').slice(0, 80);
      try {
        res.json({ places: await self.plugin.weatherSearch(name, String(req.query.language || '').slice(0, 2)) });
      } catch (e) {
        res.status(502).json({ error: 'no-answer', detail: String((e && (e.code || e.message)) || e).slice(0, 120) });
      }
    }));
    app.post('/api/weather', wrap(async function (req, res) {
      const state = await self.plugin.weatherSet(req.body || {});
      if (!state) return res.status(400).json({ error: 'bad-place' });
      res.json(state);
    }));

    // A picture the face wants: the album art the player reports for the
    // playing track, or a fanart picture, fetched from the player itself.
    // Only the player's own albumart route and the addresses the player
    // itself reported of late are fetched; anything else is not found.
    app.get('/api/face/picture', function (req, res) {
      const at = String(req.query.at || '');
      const state = (self.plugin.channel && self.plugin.channel.state) || {};
      let target = null;
      if (at.startsWith('/albumart')) target = 'http://127.0.0.1:3000' + at;
      // A theme's preview, the Manager's own, named at the player's address.
      else if (new RegExp('^http://127\\.0\\.0\\.1:' + self.port + '/api/themes/[^/]+/preview/[^/?]+(\\?thumb=1)?$').test(at)) target = at;
      else if (/^https?:\/\//.test(at) && (at === String(state.albumart || '') || ((self.plugin.channel && self.plugin.channel.arts) || []).indexOf(at) !== -1 || queue.hasCover(self.plugin.channel && self.plugin.channel.queue, at))) target = at;
      if (!target) return res.status(404).json({ error: 'not-found' });
      // A picture by the server's word or by its own first bytes.
      picture.relay(target, res, { limit: MAX_TRACK_FILE_BYTES });
    });

    // The artist's fanart set for the face, as the display asks the plugin
    // for it: the pictures in order and the slideshow settings.
    app.get('/api/face/fanart', wrap(async function (req, res) {
      const artist = String(req.query.artist || '').slice(0, 512);
      const uri = String(req.query.uri || '').slice(0, 2048);
      res.json(await self.plugin.getArtistFanart({ artist, uri }));
    }));

    // Anymote: the face on a page of its own, for any browser, with a
    // manifest so a phone keeps it on the home screen as a full-screen app.
    app.get('/anymote', function (req, res) {
      res.sendFile(path.join(__dirname, 'anymote.html'));
    });
    app.get('/anymote/manifest.json', function (req, res) {
      res.json({
        name: 'Glass Anymote',
        short_name: 'Anymote',
        start_url: '/anymote',
        display: 'fullscreen',
        orientation: 'landscape',
        background_color: '#000000',
        theme_color: '#000000',
        icons: [{ src: '/anymote/icon.svg', sizes: 'any', type: 'image/svg+xml' }]
      });
    });
    app.get('/anymote/icon.svg', function (req, res) {
      res.sendFile(path.join(__dirname, 'anymote-icon.svg'), { maxAge: 86400000 });
    });

    // Car Dash: a day theme and a night theme by the clock.
    app.get('/api/cardash', function (req, res) {
      res.json(self.plugin.carDashInfo());
    });

    app.post('/api/cardash', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.setCarDash(req.body || {}); });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.carDashInfo()));
    }));

    app.get('/api/fonts', function (req, res) {
      res.json(self.plugin.fontsSettings());
    });

    app.post('/api/fonts', wrap(async function (req, res) {
      const result = self.plugin.setFontsSettings(req.body || {});
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.fontsSettings()));
    }));

    // A font file sent as the request body, kept on the player under its name.
    app.post('/api/fonts/upload', wrap(async function (req, res) {
      const rawName = String(req.query.name || req.headers['x-file-name'] || 'font.ttf');
      const file = path.join(os.tmpdir(), 'glass-font-' + process.pid + '-' + Date.now());
      try {
        await self.receive(req, file, MAX_FONT_BYTES);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      const result = self.plugin.addCustomFont(file, rawName);
      await fsp.rm(file, { force: true });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true, name: result.name }, self.plugin.fontsSettings()));
    }));

    app.delete('/api/fonts/custom/:name', wrap(async function (req, res) {
      const result = self.plugin.removeCustomFont(String(req.params.name));
      if (result.error) return res.status(result.error === 'not-found' ? 404 : 400).json(result);
      res.json(Object.assign({ ok: true, removed: result.removed, freed: result.freed }, self.plugin.fontsSettings()));
    }));

    // The user's pictures for the screen when nothing plays: listed, one
    // served for the page to show, uploaded, removed.
    app.get('/api/backgrounds', function (req, res) {
      res.json({ backgrounds: self.plugin.backgroundsList() });
    });
    app.get('/api/backgrounds/:name/file', function (req, res) {
      const file = self.plugin.backgroundPath(String(req.params.name));
      if (!file) return res.status(404).json({ error: 'not-found' });
      res.sendFile(file, { maxAge: 0 });
    });
    app.post('/api/backgrounds/upload', wrap(async function (req, res) {
      const rawName = String(req.query.name || req.headers['x-file-name'] || 'picture');
      const file = path.join(os.tmpdir(), 'glass-background-' + process.pid + '-' + Date.now());
      try {
        await self.receive(req, file, backgrounds.MAX_BYTES);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      const result = self.plugin.backgroundAdd(file, rawName);
      await fsp.rm(file, { force: true });
      if (result.error) return res.status(400).json(result);
      res.json({ ok: true, name: result.name, backgrounds: self.plugin.backgroundsList() });
    }));
    app.delete('/api/backgrounds/:name', wrap(async function (req, res) {
      const result = self.plugin.backgroundRemove(String(req.params.name));
      if (result.error) return res.status(404).json(result);
      res.json(Object.assign({ ok: true, removed: result.removed }, self.plugin.faceSettings()));
    }));

    app.post('/api/artwork/clear-cache', wrap(async function (req, res) {
      const result = self.plugin.clearFanartImages();
      if (result.error) return res.status(500).json(result);
      res.json({ ok: true });
    }));

    // Settings the manager owns: the tag rules and whether themes survive an uninstall.
    app.get('/api/settings', function (req, res) {
      res.json(self.plugin.managerSettings());
    });

    app.post('/api/settings', wrap(async function (req, res) {
      const result = self.plugin.setManagerSettings(req.body || {});
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, self.plugin.managerSettings()));
    }));

    // Backups of the settings.
    app.get('/api/backups', function (req, res) {
      res.json({ backups: self.plugin.backupList() });
    });

    app.post('/api/backups', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.backupCreate(req.body && req.body.name); });
      if (result.error) return res.status(400).json(result);
      res.json({ ok: true, backups: self.plugin.backupList() });
    }));

    // A backup as a zip, to carry to another player.
    app.get('/api/backups/:name/download', wrap(async function (req, res) {
      const found = self.plugin.backupDir(req.params.name);
      if (found.error) return res.status(400).json({ error: found.error });
      const tmp = path.join(self.catalog.downloadsDir, 'backup-' + Date.now() + '.zip');
      await zipDirectory(found.dir, tmp);
      res.download(tmp, 'glass-backup-' + found.name + '.zip', function () {
        fsp.rm(tmp, { force: true }).catch(function () { });
      });
    }));

    // A backup zip from another player, checked before it lands.
    app.post('/api/backups/upload', wrap(async function (req, res) {
      const rawName = String(req.query.name || req.headers['x-file-name'] || '');
      const wanted = path.basename(rawName, path.extname(rawName)).replace(/^glass-backup-/, '');
      const stamp = Date.now();
      const file = path.join(self.catalog.downloadsDir, 'backup-upload-' + stamp + '.zip');
      const staging = path.join(self.catalog.downloadsDir, 'backup-staging-' + stamp);
      try {
        await self.receive(req, file, MAX_BACKUP_UPLOAD_BYTES);
        await self.unpackBackup(file, staging);
        const result = self.plugin.backupAdopt(staging, wanted);
        if (result.error) return res.status(400).json(result);
        res.json({ ok: true, name: result.name, backups: self.plugin.backupList() });
      } catch (e) {
        res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      } finally {
        await fsp.rm(file, { force: true });
        await fsp.rm(staging, { recursive: true, force: true });
      }
    }));

    app.post('/api/backups/:name/restore', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.backupRestore(req.params.name); });
      if (result.error) return res.status(400).json(result);
      res.json({ ok: true });
    }));

    app.delete('/api/backups/:name', wrap(async function (req, res) {
      const result = await self.exclusive(function () { return self.plugin.backupDelete(req.params.name); });
      if (result.error) return res.status(400).json(result);
      res.json({ ok: true, backups: self.plugin.backupList() });
    }));

    // Remote displays: what they bring into their own home, and who is connected.
    // The remotes as they stand, each with where it stands against the
    // latest release of what it is, as the Manager last saw the releases.
    app.get('/api/remote/status', function (req, res) {
      const info = self.plugin.remoteInfo();
      const latest = { Glass: self.updater.latest, 'glass-evo': self.component.latest };
      if (info && Array.isArray(info.remotes)) {
        info.remotes = info.remotes.map(function (r) { return Object.assign({}, r, { upgrade: remotebehind.standing(r, latest) }); });
      }
      res.json(info);
    });

    app.get('/api/remote/settings', function (req, res) {
      res.json(self.plugin.remoteSettings());
    });

    app.post('/api/remote/settings', wrap(async function (req, res) {
      const result = await self.plugin.setRemoteSettings(req.body || {});
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true, changed: result.changed }, self.plugin.remoteSettings()));
    }));

    app.get('/api/remote/config', function (req, res) {
      res.json(self.plugin.remoteConfig());
    });

    app.get('/api/remote/asset/:kind/:name', function (req, res) {
      const file = self.plugin.assetPath(String(req.params.kind), String(req.params.name));
      if (!file) return res.status(404).json({ error: 'not-found' });
      res.sendFile(file, { maxAge: 0 });
    });

    // A picture from the playing track's folder, for a remote's folder
    // layers, records and reels: the same names the display looks for,
    // and only the folder of the track the player reports.
    app.get('/api/remote/track-file', function (req, res) {
      const state = (self.plugin.channel && self.plugin.channel.state) || {};
      const file = trackFileFor(String(req.query.uri || ''), String(req.query.name || ''), String(state.uri || ''));
      if (!file) return res.status(404).json({ error: 'not-found' });
      fs.stat(file, function (err, stat) {
        if (err || !stat.isFile() || stat.size > MAX_TRACK_FILE_BYTES) return res.status(404).json({ error: 'not-found' });
        res.sendFile(file, { maxAge: 0 });
      });
    });

    app.get('/api/themes/:folder/files', function (req, res) {
      const folder = self.folderParam(req);
      const files = self.plugin.themeFiles(folder);
      if (!files) return res.status(404).json({ error: 'not-found' });
      res.json(files);
    });

    // Every file the theme's text names, found or missing where the
    // display looks: the detail view's Files section.
    app.get('/api/themes/:folder/named', function (req, res) {
      const folder = self.folderParam(req);
      const named = self.themeFiles(folder);
      if (!named) return res.status(404).json({ error: 'not-found' });
      res.json(named);
    });

    app.get('/api/themes/:folder/file', function (req, res) {
      const folder = self.folderParam(req);
      const file = self.plugin.themeFilePath(folder, String(req.query.tree || 'templates'), String(req.query.path || ''));
      if (!file) return res.status(404).json({ error: 'not-found' });
      res.sendFile(file, { maxAge: 0 });
    });

    // Logging: the level and targets, and the last lines from the journal.
    app.get('/api/logging', function (req, res) {
      res.json(Object.assign({ levels: logging.LEVELS, targetsAvailable: logging.TARGETS }, self.plugin.logSettings()));
    });

    app.post('/api/logging', function (req, res) {
      res.json(Object.assign({ ok: true, levels: logging.LEVELS, targetsAvailable: logging.TARGETS }, self.plugin.setLogSettings(req.body || {})));
    });

    app.get('/api/logs', function (req, res) {
      const found = self.plugin.recentLog(req.query.lines);
      if (found.error) return res.status(500).json(found);
      if (req.query.download === '1') {
        const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
        res.setHeader('Content-Disposition', 'attachment; filename="glass-log-' + os.hostname() + '-' + stamp + '.txt"');
        res.type('text/plain').send(found.lines.join('\n') + '\n');
        return;
      }
      res.json(found);
    });

    // The performance profile.
    app.get('/api/performance', function (req, res) {
      res.json(self.plugin.performanceInfo());
    });

    app.post('/api/performance', wrap(async function (req, res) {
      const body = req.body || {};
      const result = await self.exclusive(function () {
        let changed = false;
        if (typeof body.governor === 'boolean') {
          const g = self.plugin.setGovernor(body.governor);
          if (g.error) return g;
          changed = changed || !!g.changed;
        }
        if (body.profile !== undefined) {
          const p = self.plugin.applyPerformanceProfile(body.profile);
          if (p.error) return p;
          return Object.assign(p, { changed: changed || !!p.changed });
        }
        return Object.assign({ changed: changed }, self.plugin.performanceInfo());
      });
      if (result.error) return res.status(400).json(result);
      res.json(Object.assign({ ok: true }, result));
    }));

    // Upgrading Glass itself.
    const uploadOn = function () { return typeof self.plugin.uploadInstall === 'function' && self.plugin.uploadInstall() === true; };
    app.get('/api/update', wrap(async function (req, res) {
      try {
        res.json(Object.assign(await self.updater.check(false), { upload: uploadOn(), held: self.held.summary() }));
      } catch (e) {
        res.json(Object.assign(self.updater.view(), { upload: uploadOn(), held: self.held.summary(), error: failure(e) }));
      }
    }));

    app.post('/api/update/check', wrap(async function (req, res) {
      try {
        res.json(await self.updater.check(true));
      } catch (e) {
        res.status(502).json(Object.assign(self.updater.view(), { error: failure(e) }));
      }
    }));

    // Test releases: whether this player is offered a release still marked
    // a pre-release, of Glass and of glass-evo alike. The choice is looked
    // up at once, so the page shows what it brings.
    app.post('/api/update/test', wrap(async function (req, res) {
      const body = req.body || {};
      if (typeof body.test !== 'boolean') return res.status(400).json({ error: 'bad-request', message: 'test must be true or false' });
      const result = self.plugin.setTestReleases(body.test);
      let update;
      let evo;
      try { update = await self.updater.check(true); } catch (e) { update = Object.assign(self.updater.view(), { error: failure(e) }); }
      try { evo = await self.component.check(true); } catch (e) { evo = Object.assign(self.component.view(), { error: failure(e) }); }
      res.json({ ok: true, changed: result.changed, test: result.test, update: update, evo: evo });
    }));

    // One upgrade at a time. A job left in `restarting` for minutes means
    // the restart did not happen; it no longer stands in the way.
    const upgrading = function () {
      return self.jobs.some(function (j) {
        if (j.kind !== 'upgrade' && j.kind !== 'rollback' && j.kind !== 'stable') return false;
        if (j.state === 'done' || j.state === 'failed') return false;
        if (j.state === 'restarting' && Date.now() - Date.parse(j.endedAt || j.startedAt) > 180000) return false;
        return true;
      });
    };

    app.post('/api/update/install', wrap(async function (req, res) {
      const view = self.updater.view();
      if (!view.available) return res.status(400).json({ error: 'up-to-date' });
      if (upgrading()) return res.status(409).json({ error: 'busy' });
      const job = self.newJob('upgrade', 'Glass ' + view.latest.version);
      job.target = view.latest.version;
      self.runUpgrade(job, false);
      res.status(202).json({ ok: true, job: job });
    }));

    app.post('/api/update/rollback', wrap(async function (req, res) {
      const previous = self.updater.previous();
      if (!previous) return res.status(400).json({ error: 'no-previous' });
      if (upgrading()) return res.status(409).json({ error: 'busy' });
      const job = self.newJob('rollback', 'Glass ' + previous.version);
      job.target = previous.version;
      self.runUpgrade(job, true);
      res.status(202).json({ ok: true, job: job });
    }));

    // Install from a file: an extra for a player that cannot reach
    // GitHub's files, off unless turned on. Off, the uploads are refused.
    app.post('/api/update/upload-switch', wrap(async function (req, res) {
      const body = req.body || {};
      if (typeof body.upload !== 'boolean') return res.status(400).json({ error: 'bad-request', message: 'upload must be true or false' });
      const result = self.plugin.setUploadInstall(body.upload);
      if (!body.upload) await self.held.clear();
      res.json({ ok: true, changed: result.changed, upload: result.upload, held: self.held.summary() });
    }));

    // A Glass release zip as the request body: what it says it is read,
    // the pairing rule asked, then the job runs the plan: installed as the
    // online path installs, with the glass-evo zip kept from before where
    // it fits, with the glass-evo fetched where that Glass needs a newer
    // one and the player can see it, or kept on the player for the
    // glass-evo zip that will complete it. The job says which it will be.
    app.post('/api/update/upload', wrap(async function (req, res) {
      if (!uploadOn()) return res.status(403).json({ error: 'switch-off', message: 'install from a file is off on this player' });
      if (upgrading()) return res.status(409).json({ error: 'busy' });
      await fsp.mkdir(self.updater.stagingDir, { recursive: true });
      const file = path.join(self.updater.stagingDir, 'upload-' + Date.now() + '.zip');
      try {
        await self.receive(req, file, MAX_ZIP_BYTES);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      let seen;
      try {
        seen = await examineGlassZip(file);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(400).json(failure(e));
      }
      const zip = { kind: 'glass', version: seen.version, least: seen.least };
      const job = self.newJob('upgrade', 'Glass ' + seen.version);
      job.will = self.pairingPlan(zip).action;
      self.runUploadInstall(job, file, zip);
      res.status(202).json({ ok: true, job: job });
    }));

    // A kept zip discarded by the user.
    app.delete('/api/update/held/:kind', wrap(async function (req, res) {
      const kind = String(req.params.kind || '');
      if (kind !== 'glass' && kind !== 'evo') return res.status(400).json({ error: 'bad-request', message: 'kind is glass or evo' });
      const dropped = await self.held.drop(kind);
      if (!dropped) return res.status(404).json({ error: 'not-found', message: 'no ' + (kind === 'glass' ? 'Glass' : 'glass-evo') + ' zip is kept' });
      res.json({ ok: true, dropped: { kind: kind, version: dropped.version }, held: self.held.summary() });
    }));

    // The shelf for remotes: the archives kept for the remotes' machines,
    // offered on the network in the shape GitHub's releases have, so a
    // remote looks at its player first. Behind the same switch: off, the
    // uploads are refused and nothing is served, and a remote goes to
    // GitHub as before.
    app.get('/api/shelf', wrap(async function (req, res) {
      res.json(Object.assign(await self.shelf.view(), { upload: uploadOn() }));
    }));

    app.post('/api/shelf/ceiling', wrap(async function (req, res) {
      const body = req.body || {};
      if (!Number.isFinite(Number(body.mb))) return res.status(400).json({ error: 'bad-request', message: 'mb must be a number' });
      const result = self.plugin.setShelfCeilingMb(Number(body.mb));
      res.json({ ok: true, changed: result.changed, ceilingMb: result.ceilingMb });
    }));

    // A remote's release archive as the request body: held to the
    // signature it carries inside, named by what it says it is, placed
    // with the one of the same product and platform dropped.
    app.post('/api/shelf', wrap(async function (req, res) {
      if (!uploadOn()) return res.status(403).json({ error: 'switch-off', message: 'install from a file is off on this player' });
      await fsp.mkdir(self.shelf.dir, { recursive: true });
      const file = path.join(self.shelf.dir, 'incoming-' + Date.now());
      try {
        await self.receive(req, file, MAX_SHELF_ARCHIVE);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      try {
        const placed = await self.shelf.place(file);
        res.json(Object.assign({ ok: true, archive: placed }, await self.shelf.view()));
      } catch (e) {
        res.status(e.code === 'shelf-full' ? 409 : 400).json(failure(e));
      }
    }));

    app.delete('/api/shelf/:name', wrap(async function (req, res) {
      const gone = await self.shelf.remove(String(req.params.name || ''));
      if (!gone) return res.status(404).json({ error: 'not-found' });
      res.json(Object.assign({ ok: true }, await self.shelf.view()));
    }));

    // What a remote reads: the shelf's archives of its product as a list
    // of releases, the assets at this player's address as the remote
    // reached it.
    const shelfBase = function (req) {
      return 'http://' + String(req.headers.host || ('127.0.0.1:' + self.port)).replace(/[^A-Za-z0-9.:\[\]-]/g, '');
    };
    app.get('/api/shelf/releases', wrap(async function (req, res) {
      if (!uploadOn()) return res.status(403).json({ error: 'switch-off', message: 'install from a file is off on this player' });
      res.json(await self.shelf.releases(String(req.query.product || ''), shelfBase(req)));
    }));

    app.get('/api/shelf/files/:name', wrap(async function (req, res) {
      if (!uploadOn()) return res.status(403).json({ error: 'switch-off', message: 'install from a file is off on this player' });
      const found = await self.shelf.file(String(req.params.name || ''));
      if (!found) return res.status(404).json({ error: 'not-found' });
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Length', String(found.bytes));
      res.setHeader('Cache-Control', 'no-store');
      fs.createReadStream(found.path).on('error', function () { res.destroy(); }).pipe(res);
    }));

    // Back to the stable release: what the act would do on this player
    // and the questions it asks first, then the act itself with the
    // answers. An answer left out is the suggested one.
    app.get('/api/stable', wrap(async function (req, res) {
      res.json(await self.stableView());
    }));

    app.post('/api/stable', wrap(async function (req, res) {
      if (upgrading()) return res.status(409).json({ error: 'busy' });
      const view = await self.stableView();
      if (view.error) return res.status(502).json(view);
      const keep = stable.answers((req.body || {}).keep, view.facts);
      const job = self.newJob('stable', 'Glass ' + view.glass.to);
      job.target = view.glass.to;
      job.same = view.glass.action === 'none';
      self.runStable(job, keep);
      res.status(202).json({ ok: true, job: job, keep: keep });
    }));

    // glass-evo, the component: what is here, the latest release, and
    // whether the screen is its own.
    const evoView = function (extra) {
      return Object.assign(self.component.view(), { owner: self.plugin.screenOwnerState().owner }, extra || {});
    };
    const componentBusy = function () {
      return upgrading() || self.jobs.some(function (j) { return j.kind === 'component' && j.state !== 'done' && j.state !== 'failed'; });
    };

    app.get('/api/evo', wrap(async function (req, res) {
      try {
        await self.component.check(false);
        res.json(evoView());
      } catch (e) {
        res.json(evoView({ error: failure(e) }));
      }
    }));

    app.post('/api/evo/check', wrap(async function (req, res) {
      try {
        await self.component.check(true);
        res.json(evoView());
      } catch (e) {
        res.status(502).json(evoView({ error: failure(e) }));
      }
    }));

    app.post('/api/evo/install', wrap(async function (req, res) {
      const view = self.component.view();
      if (!view.available) return res.status(400).json({ error: view.behind ? 'too-old' : 'up-to-date' });
      if (componentBusy()) return res.status(409).json({ error: 'busy' });
      const job = self.newJob('component', 'glass-evo ' + view.latest.version);
      self.runComponent(job, false);
      res.status(202).json({ ok: true, job: job });
    }));

    app.post('/api/evo/rollback', wrap(async function (req, res) {
      const previous = self.component.previous();
      if (!previous) return res.status(400).json({ error: 'no-previous' });
      if (componentBusy()) return res.status(409).json({ error: 'busy' });
      const job = self.newJob('component', 'glass-evo ' + previous.version);
      self.runComponent(job, true);
      res.status(202).json({ ok: true, job: job });
    }));

    // A glass-evo release zip as the request body: what it says it is
    // read, the pairing rule asked, then the job runs the plan: installed
    // in place and held to this Glass, installed with the Glass zip kept
    // from before where it fits that one (the job is then an upgrade, the
    // backend restarting), or kept on the player for the Glass zip that
    // will complete it. With `hold`, verified and kept outright for the
    // Glass zip that follows at once. Refused while the switch is off.
    app.post('/api/evo/upload', wrap(async function (req, res) {
      if (!uploadOn()) return res.status(403).json({ error: 'switch-off', message: 'install from a file is off on this player' });
      if (componentBusy()) return res.status(409).json({ error: 'busy' });
      await fsp.mkdir(self.component.stateDir, { recursive: true });
      const file = path.join(self.component.stateDir, 'upload-' + Date.now() + '.zip');
      try {
        await self.receive(req, file, MAX_ZIP_BYTES);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(e.code === 'too-large' ? 413 : 400).json(failure(e));
      }
      if (String(req.query.hold || '') === '1') {
        try {
          const seen = await self.component.examineFile({ state: 'queued' }, file);
          await self.held.keep('evo', file, { version: seen.version, requires: seen.requires, verified: seen.verified });
        } catch (e) {
          await fsp.rm(file, { force: true });
          return res.status(400).json(failure(e));
        }
        return res.json({ ok: true, held: self.held.summary() });
      }
      let seen;
      try {
        seen = await manifestFactsOf(file);
      } catch (e) {
        await fsp.rm(file, { force: true });
        return res.status(400).json(failure(e));
      }
      const zip = { kind: 'evo', version: seen.version, requires: seen.requires };
      const will = self.pairingPlan(zip).action;
      const both = will === 'install-both';
      const job = self.newJob(both ? 'upgrade' : 'component', 'glass-evo ' + seen.version);
      job.will = will;
      if (both) job.target = self.held.get('glass').version;
      self.runComponentFile(job, file, zip);
      res.status(202).json({ ok: true, job: job });
    }));

    // Removed only while the kiosk owns the screen: the face is not taken
    // from under a player whose interface it is.
    app.post('/api/evo/remove', wrap(async function (req, res) {
      if (componentBusy()) return res.status(409).json({ error: 'busy' });
      const result = await self.exclusive(async function () {
        if (self.plugin.screenOwnerState().owner === 'glass-evo') return { error: 'owns-screen' };
        return self.component.remove();
      });
      if (result.error) return res.status(409).json(result);
      res.json(evoView({ ok: true }));
    }));

    app.use('/api', function (req, res) {
      res.status(404).json({ error: 'not-found' });
    });
  }

  folderParam(req) {
    const folder = String(req.params.folder || '');
    if (!safeFolderName(folder)) {
      const e = new Error('bad folder name');
      e.status = 400;
      e.code = 'bad-folder';
      throw e;
    }
    return folder;
  }

  // ---- views -----------------------------------------------------------

  async status() {
    const plugin = this.plugin;
    const info = plugin.statusInfo();
    let free = null;
    try {
      const stat = await fsp.statfs(this.paths.dataDir);
      free = stat.bavail * stat.bsize;
    } catch (e) { /* unknown */ }
    const rings = await readRings();
    const playing = !!(info.channel && info.channel.status === 'play');
    let remotes = null;
    try {
      const r = plugin.remoteInfo();
      remotes = {
        enabled: !!(r.ports && r.ports.enabled),
        serving: !!r.serving,
        ports: r.ports,
        receiving: r.serve && Array.isArray(r.serve.subscribers) ? r.serve.subscribers.length : 0,
        connected: Array.isArray(r.remotes) ? r.remotes.length : 0,
        problem: (r.errors && (r.errors.serve || r.errors.channel)) || null
      };
    } catch (e) { /* the plugin has no remotes to report */ }
    // glass-evo's facts, the remotes connected and the theme's own fonts:
    // each left out where it cannot be read, the sheet stands without it.
    let evo = null;
    let remoteList = null;
    let themeFiles = null;
    try { evo = sheetfacts.evo(this.evoFacts(info)); } catch (e) { /* not all there */ }
    try {
      remoteList = sheetfacts.remoteRows(plugin.remoteInfo().remotes, { Glass: this.updater.latest, 'glass-evo': this.component.latest }, remotebehind.standing);
    } catch (e) { /* no channel */ }
    try { const named = this.themeFiles(info.activeTheme); themeFiles = named ? named.files : null; } catch (e) { /* no theme */ }
    return Object.assign(info, {
      measured: playing && rings.some(function (r) { return r.live; }),
      remotes: remotes,
      remoteList: remoteList,
      evo: evo,
      themeFiles: themeFiles,
      manager: { port: this.port, url: this.url(), uptimeS: Math.round(process.uptime()) },
      catalog: {
        fetchedAt: this.catalog.fetchedAt,
        updated: this.catalog.index ? this.catalog.index.updated : null,
        count: this.catalog.entries().length,
        installed: Object.keys(this.catalog.installed).length
      },
      rings: rings,
      diskFree: free,
      hostname: os.hostname(),
      upgrade: { last: (this.updater.state && this.updater.state.last) || null, previous: this.updater.previous(), test: this.plugin.testReleases(), job: this.lastInstallJob(), held: this.held.summary() },
      themeSize: (function () { const m = SIZE_PREFIX.exec(String(info.activeTheme || '')); return m ? m[1] + 'x' + m[2] : ''; })(),
      jobs: this.jobs.filter(function (j) { return j.state !== 'done' && j.state !== 'failed'; }).length
    });
  }

  // The raw facts of glass-evo for the sheet, from what the plugin and the
  // component hold; a fact that cannot be read is left out and the sheet
  // says what it can. `info` is the plugin's status, read already.
  evoFacts(info) {
    const plugin = this.plugin;
    const f = { now: Date.now() };
    const read = function (name, fn) { try { f[name] = fn(); } catch (e) { /* left out */ } };
    read('component', () => this.component.view());
    read('owner', () => { const o = plugin.screenOwnerState(); return { owner: o.owner, mode: o.mode }; });
    read('display', () => plugin.displayFacts());
    if (f.display) {
      f.displayBinary = f.display.binary;
      f.displayStartedAt = f.display.since;
      f.componentInstalledAt = f.display.componentInstalledAt;
    }
    read('module', () => { const m = plugin.faceModule(); return { mode: m.mode, face: m.face, has: m.has, version: m.version }; });
    f.pages = info && info.face && typeof info.face.pages === 'number' ? info.face.pages : null;
    read('look', () => {
      const s = plugin.faceSettings();
      const own = plugin.faceThemeFilesOf(s.settings.theme);
      return { settings: s.settings, builtIn: s.builtIn, looks: s.looks, themeLook: s.themeLook, files: own ? own.files : [], frostSuits: s.frostSuits };
    });
    read('persistS', () => plugin.persistSettings().seconds);
    read('themeSkies', () => {
      const theme = String(info && info.activeTheme || '');
      if (!theme || theme.indexOf('/') !== -1 || theme.indexOf('..') !== -1) return [];
      return fs.readdirSync(path.join(this.paths.meterBase, theme, 'skies'));
    });
    read('picture', () => ({ found: !!plugin.backgroundPath(String((f.look && f.look.settings['idle.picture']) || '')) }));
    read('faceSize', () => plugin.screenSettings().faceSize);
    read('weather', () => plugin.weatherState());
    return f;
  }

  // Every file a theme names, each found or missing where the display
  // looks (optional where the display does without it); null where the
  // theme is not read. For the sheet, the diagnosis and the Themes tab.
  themeFiles(theme) {
    const name = String(theme || '');
    if (!name || name.indexOf('/') !== -1 || name.indexOf('..') !== -1) return null;
    const dir = path.join(this.paths.meterBase, name);
    let text;
    try { text = fs.readFileSync(path.join(dir, 'meters.txt'), 'utf8'); } catch (e) { return null; }
    const files = sheetfacts.themeFiles(text, dir, this.plugin.fontPathDir() || '', function (p) {
      try { return fs.statSync(p).isFile(); } catch (e) { return false; }
    });
    return { folder: name, dir: dir, files: files, summary: sheetfacts.themeFilesSummary(files) };
  }

  async themes() {
    const self = this;
    const list = self.plugin.themeList();
    const byFolder = {};
    Object.keys(self.catalog.installed).forEach(function (name) {
      (self.catalog.installed[name].folders || []).forEach(function (f) {
        if (f.install === 'templates') byFolder[f.folder] = name;
      });
    });
    for (const theme of list) {
      const metersFile = path.join(self.paths.meterBase, theme.folder, 'meters.txt');
      theme.previews = theme.meters.length ? await self.previews.status(theme.folder, metersFile) : 'none';
      theme.catalog = byFolder[theme.folder] || null;
      // What the theme names and does not have, for the card's red count.
      try { const named = self.themeFiles(theme.folder); theme.named = named ? named.summary : null; } catch (e) { theme.named = null; }
      const size = SIZE_PREFIX.exec(theme.folder);
      theme.width = size ? parseInt(size[1], 10) : theme.width || null;
      theme.height = size ? parseInt(size[2], 10) : theme.height || null;
    }
    return {
      active: self.plugin.activeTheme(),
      meterBase: self.paths.meterBase,
      spectrumBase: self.paths.spectrumBase,
      themes: list
    };
  }

  async previewsOf(folder) {
    const metersFile = path.join(this.paths.meterBase, folder, 'meters.txt');
    const state = await this.previews.status(folder, metersFile);
    const meters = await this.previews.list(folder);
    return {
      folder: folder,
      state: state,
      meters: meters.map(function (m) {
        const base = '/api/themes/' + encodeURIComponent(folder) + '/preview/' + encodeURIComponent(m);
        return { meter: m, url: base, thumb: base + '?thumb=1' };
      })
    };
  }

  catalogView(error) {
    const self = this;
    const exists = function (install, folder) {
      const base = install === 'templates' ? self.paths.meterBase : self.paths.spectrumBase;
      return fs.existsSync(path.join(base, folder));
    };
    const entries = self.catalog.entries().map(function (t) {
      return {
        name: t.name,
        kind: t.kind,
        category: t.category,
        width: t.width,
        height: t.height,
        bytes: t.bytes,
        units: t.units,
        thumb: t.thumb ? '/api/catalog/thumb/' + encodeURIComponent(t.name) : null,
        preview: t.preview ? self.catalog.url(t.preview) : null,
        state: self.catalog.state(t, exists)
      };
    });
    return {
      fetchedAt: self.catalog.fetchedAt,
      updated: self.catalog.index ? self.catalog.index.updated : null,
      source: self.catalog.indexUrl,
      error: error ? failure(error) : null,
      entries: entries
    };
  }

  // ---- jobs ------------------------------------------------------------

  newJob(kind, name) {
    const job = {
      id: ++this.jobSeq,
      kind: kind,
      name: name,
      state: 'queued',
      progress: { done: 0, total: 0 },
      folders: [],
      error: null,
      startedAt: new Date().toISOString(),
      endedAt: null
    };
    this.jobs.push(job);
    while (this.jobs.length > JOBS_KEPT) this.jobs.shift();
    return job;
  }

  finish(job, error) {
    job.endedAt = new Date().toISOString();
    if (error) {
      job.state = 'failed';
      job.error = failure(error);
      this.logger.warn('glass: manager ' + job.kind + ' ' + job.name + ' failed: ' + job.error.message);
    } else {
      job.state = 'done';
      if (!error && job.kind !== 'upgrade' && job.kind !== 'component' && this.plugin && typeof this.plugin.themesWritten === 'function') { try { this.plugin.themesWritten(); } catch (e) { } }
      this.logger.info('glass: manager ' + job.kind + ' ' + job.name + ' done: ' + job.folders.map(function (f) { return f.install + '/' + f.folder; }).join(', '));
    }
  }

  // The newest install that ended, an upgrade, a rollback, a glass-evo
  // install or a return to the stable release, for the sheet and the
  // checks: one refused or failed stands here, with its error, until the
  // next such job or a restart of the backend.
  lastInstallJob() {
    const kinds = ['upgrade', 'rollback', 'component', 'stable'];
    for (let i = this.jobs.length - 1; i >= 0; i--) {
      const j = this.jobs[i];
      if (kinds.indexOf(j.kind) === -1 || (j.state !== 'done' && j.state !== 'failed')) continue;
      return { kind: j.kind, name: j.name, state: j.state, error: j.error || null, endedAt: j.endedAt || null, held: j.held || null };
    }
    return null;
  }

  // The pairing rule asked for a zip brought by hand, against what runs,
  // what is kept of the other kind, and, where the answer would be to keep
  // the zip, what the player can see online: a Glass that needs a newer
  // glass-evo takes the latest released where that satisfies it, as the
  // online upgrade does. `online` false asks without looking online.
  pairingPlan(zip, online) {
    const here = this.component.installed();
    const facts = { glass: this.updater.version, evo: here.installed ? here.version : null, least: this.component.least, zip: zip, held: this.held.get(zip.kind === 'glass' ? 'evo' : 'glass'), online: null };
    const first = pairing.plan(facts);
    if (!online) return first;
    if (first.action === 'hold-glass') {
      // Only a look that succeeds counts: the release list kept from an
      // earlier look says nothing about whether GitHub is reachable now.
      return this.component.check(true).then(
        () => { const latest = this.component.latest; return latest ? latest.version : null; },
        () => null
      ).then((evo) => pairing.plan(Object.assign({}, facts, { online: { evo: evo } })));
    }
    if (first.action === 'hold-evo') {
      const latest = this.updater.latest;
      return Promise.resolve(pairing.plan(Object.assign({}, facts, { online: { glass: latest ? latest.version : null } })));
    }
    return Promise.resolve(first);
  }

  // A kept zip that has become moot is let go: a Glass of the version
  // running, a glass-evo of the version installed or older than the
  // running Glass works with.
  async pruneHeld() {
    const g = this.held.get('glass');
    if (g && g.version === this.updater.version) await this.held.drop('glass');
    const e = this.held.get('evo');
    if (!e) return;
    const here = this.component.installed();
    if ((here.installed && here.version === e.version) || (this.component.least && compareVersions(e.version, this.component.least) < 0)) await this.held.drop('evo');
  }

  // Cut a theme to a size into a staging folder, then move the copy and
  // its twin into the trees, replacing a copy of that name, and draw its
  // previews.
  runTailor(job, folder, size, stretch) {
    const self = this;
    self.exclusive(async function () {
      const staging = path.join(self.catalog.downloadsDir, 'tailor-' + job.id);
      try {
        await fsp.rm(staging, { recursive: true, force: true });
        await fsp.mkdir(staging, { recursive: true });
        try { await fsp.chown(staging, self.previews.uid, self.previews.gid); } catch (e) { /* same user */ }
        job.state = 'cutting';
        const result = await tailor.cut({
          launcher: self.paths.launcher, env: self.plugin.launchEnv(), uid: self.previews.uid, gid: self.previews.gid,
          themeDir: path.join(self.paths.meterBase, folder), width: size.width, height: size.height, stretch: stretch, out: staging
        });
        result.warnings.forEach(function (w) { self.logger.info('glass: manager tailor ' + folder + ': ' + w); });
        job.state = 'unpacking';
        for (const f of result.folders) {
          const root = f.install === 'templates' ? self.paths.meterBase : self.paths.spectrumBase;
          await fsp.mkdir(root, { recursive: true });
          const dest = path.join(root, f.folder);
          await fsp.rm(dest, { recursive: true, force: true });
          await fsp.rename(f.path, dest);
          await ownTree(dest, self.previews.uid, self.previews.gid);
          job.folders.push({ install: f.install, folder: f.folder, kind: f.install === 'templates' ? 'meter' : 'spectrum', files: 0, bytes: 0, names: [] });
        }
        await self.afterInstall(job);
        self.finish(job, null);
      } catch (e) {
        self.finish(job, e);
      } finally {
        await fsp.rm(staging, { recursive: true, force: true });
      }
    });
  }

  // Package a theme into the downloads folder; the zip stays for the
  // browser to fetch until the plugin starts again.
  runPackage(job, folder, settle) {
    const self = this;
    self.exclusive(async function () {
      const staging = path.join(self.catalog.downloadsDir, 'package-' + job.id);
      try {
        await fsp.rm(staging, { recursive: true, force: true });
        await fsp.mkdir(staging, { recursive: true });
        try { await fsp.chown(staging, self.previews.uid, self.previews.gid); } catch (e) { /* same user */ }
        job.state = 'packaging';
        let total = 0;
        try {
          total = fs.readFileSync(path.join(self.paths.meterBase, folder, 'meters.txt'), 'utf8').split('\n').filter(function (l) { return /^\s*\[/.test(l); }).length;
        } catch (e) { /* unknown: the bar waits */ }
        job.progress = { done: 0, total: total };
        job.settle = settle;
        const result = await tailor.pack({
          launcher: self.paths.launcher, env: self.plugin.launchEnv(), uid: self.previews.uid, gid: self.previews.gid,
          themeDir: path.join(self.paths.meterBase, folder), out: staging, settle: settle,
          onProgress: function (done) { job.progress = { done: done, total: Math.max(total, done) }; }
        });
        result.warnings.forEach(function (w) { self.logger.info('glass: manager package ' + folder + ': ' + w); });
        job.file = result.zip;
        job.state = 'done';
        job.endedAt = new Date().toISOString();
        self.logger.info('glass: manager package ' + folder + ' done: ' + result.zip);
      } catch (e) {
        await fsp.rm(staging, { recursive: true, force: true });
        self.finish(job, e);
      }
    });
  }

  runInstall(job, entry) {
    const self = this;
    self.exclusive(async function () {
      let file = null;
      try {
        job.state = 'downloading';
        const got = await self.catalog.downloadCurrent(entry.name, function (done, total) {
          job.progress = { done: done, total: total };
        });
        file = got.file;
        entry = got.entry;
        job.state = 'checking';
        const zip = await Zip.open(file);
        try {
          const found = await unitsOf(zip, entry.name);
          if (found.problems.length) throw new ZipError('bad-theme', found.problems.join('; '));
          if (!sameUnits(found.units, entry.units)) throw new ZipError('units-differ', 'the zip does not hold the folders the catalog names');
          job.state = 'unpacking';
          job.folders = await self.unpack(zip, found.units, job);
        } finally {
          await zip.close();
        }
        await self.catalog.markInstalled(entry, job.folders);
        await self.afterInstall(job);
        self.finish(job, null);
      } catch (e) {
        self.finish(job, e);
      } finally {
        if (file) await self.catalog.discard(file);
      }
    });
  }

  // Replace the plugin with the latest release, or with the kept previous
  // version. The job ends in `restarting`: the backend goes down with this
  // process's state, and the page waits for the new version to answer.
  runUpgrade(job, rollback) {
    const self = this;
    self.exclusive(async function () {
      try {
        const staged = rollback ? await self.updater.stagePrevious(job) : await self.updater.download(job);
        // The component here is brought to what that Glass works with
        // first, a glass-evo zip kept from an earlier upload used before
        // any is fetched.
        const kept = self.held.get('evo');
        const paired = await pair(self.component, staged, job, { held: kept });
        if (kept && kept.used) await self.held.take('evo');
        let result;
        try {
          result = await self.updater.apply(job, staged);
        } catch (e) {
          // The Glass did not go in: the component it was brought forward for goes back.
          if (paired) {
            try { await self.component.rollback(); } catch (e2) { self.logger.warn('glass: manager component: not put back after the upgrade failed: ' + e2.message); }
          }
          throw e;
        }
        job.endedAt = new Date().toISOString();
        self.logger.info('glass: manager ' + job.kind + ' from ' + result.from + ' to ' + result.to + ': plugin replaced, backend restarting');
      } catch (e) {
        self.finish(job, e);
      }
    });
  }

  // What the way back to the stable release would do here: the step of
  // Glass and of glass-evo to their latest release that is no test
  // release, and the questions asked first. The releases are asked of
  // GitHub at every call; what cannot be asked is said as an error.
  async stableView() {
    const self = this;
    const facts = self.plugin.stableFacts();
    const out = { facts: facts, questions: stable.questions(facts), glass: null, evo: null };
    try {
      const glass = await self.updater.stable();
      out.glass = stable.step(self.updater.version, glass.version, compareVersions);
      const here = self.component.installed();
      const evo = here.installed ? await self.component.stable() : null;
      out.evo = stable.step(here.installed ? here.version : null, evo ? evo.version : null, compareVersions);
    } catch (e) {
      out.error = failure(e);
    }
    return out;
  }

  // Back to the stable release, with the user's answers: the act is the
  // module's own (`stable.run`), given what it works with here. The job
  // ends in `restarting`, as an upgrade's does.
  runStable(job, keep) {
    const self = this;
    self.exclusive(async function () {
      try {
        await stable.run(job, keep, { updater: self.updater, component: self.component, plugin: self.plugin, texts: releaseTexts, least: leastOf, logger: self.logger });
        job.endedAt = new Date().toISOString();
      } catch (e) {
        self.finish(job, e);
      }
    });
  }

  // Get or update the component, or put the one before back; a face on
  // the screen then comes back as the one now in place.
  runComponent(job, rollback) {
    const self = this;
    self.exclusive(async function () {
      try {
        if (rollback) await self.component.rollback();
        else await self.component.install(job);
        self.plugin.componentChanged();
        self.finish(job, null);
      } catch (e) {
        self.finish(job, e);
      }
    });
  }

  // A Glass release brought by hand runs the pairing rule's plan: the
  // glass-evo zip kept from before goes in first where it fits, the Glass
  // then as the online path's does; a Glass that needs a newer glass-evo
  // takes the latest released where the player sees one that satisfies
  // it, else is kept on the player for the glass-evo zip to come. `zip`
  // is what the file says it is, read by the route.
  runUploadInstall(job, file, zip) {
    const self = this;
    self.exclusive(async function () {
      let kept = null;
      let paired = false;
      try {
        const p = await self.pairingPlan(zip, true);
        job.will = p.action;
        if (p.dropped) {
          await self.held.drop('evo');
          self.logger.info('glass: manager upgrade: the kept glass-evo ' + p.dropped.version + ' zip does not go with Glass ' + zip.version + '; discarded');
        }
        if (p.action === 'nothing') {
          await fsp.rm(file, { force: true });
          throw new UpdateError('same-version', 'Glass ' + zip.version + ' is what runs; nothing to install');
        }
        if (p.action === 'hold-glass') {
          const release = await self.updater.verifyFile(job, file, zip.version);
          await self.held.keep('glass', file, { version: zip.version, least: zip.least, verified: release.verified });
          job.held = { kind: 'glass', version: zip.version, needs: p.needs };
          job.name = 'Glass ' + zip.version + ' (kept)';
          self.logger.info('glass: manager upgrade: Glass ' + zip.version + ' kept; it needs glass-evo ' + p.needs + ' or later, which the player does not have');
          self.finish(job, null);
          return;
        }
        if (p.action === 'install-held' || p.action === 'install-both') {
          // The kept glass-evo goes in first, held to the Glass that will run.
          kept = await self.held.take('evo');
          const glassToRun = p.action === 'install-held' ? self.updater.version : zip.version;
          await self.component.installFile(job, kept.file, { glass: glassToRun, least: zip.least || self.component.least });
          paired = true;
          self.plugin.componentChanged();
          self.logger.info('glass: manager upgrade: the kept glass-evo ' + kept.version + ' installed from a file' + (p.action === 'install-held' ? '' : ' with Glass ' + zip.version));
          if (p.action === 'install-held') {
            await fsp.rm(file, { force: true });
            job.name = 'glass-evo ' + kept.version + ' · Glass ' + zip.version + ' is what runs';
            await self.pruneHeld();
            self.finish(job, null);
            return;
          }
        }
        const staged = await self.updater.stageFile(job, file);
        job.name = 'Glass ' + staged.version;
        job.target = staged.version;
        // The pair rule once more, as the online path has it: satisfied by
        // the kept zip or by what is installed, or, where the player sees
        // the glass-evo it needs online, fetching it.
        const fetching = p.action === 'install-glass-fetching-evo';
        try {
          paired = (await pair(self.component, staged, job, fetching ? {} : { byHand: true })) || paired;
        } catch (e) {
          if (!fetching) throw e;
          // The glass-evo it needs could not be fetched after all: the
          // Glass, verified already, is kept for the zip, as it is where
          // the player cannot see GitHub at all.
          await self.held.keep('glass', staged.file, { version: staged.version, least: staged.least, verified: staged.verified });
          job.will = 'hold-glass';
          job.held = { kind: 'glass', version: staged.version, needs: zip.least };
          job.name = 'Glass ' + staged.version + ' (kept)';
          job.target = null;
          self.logger.info('glass: manager upgrade: Glass ' + staged.version + ' kept; the glass-evo it needs could not be fetched (' + (e && e.message ? e.message : e) + ')');
          self.finish(job, null);
          return;
        }
        let result;
        try {
          result = await self.updater.apply(job, staged);
        } catch (e) {
          if (paired) {
            try { await self.component.rollback(); } catch (e2) { self.logger.warn('glass: manager component: not put back after the upgrade failed: ' + e2.message); }
          }
          throw e;
        }
        job.endedAt = new Date().toISOString();
        self.logger.info('glass: manager ' + job.kind + ' from ' + result.from + ' to ' + result.to + ' from a file: plugin replaced, backend restarting');
      } catch (e) {
        await fsp.rm(file, { force: true });
        if (kept) await fsp.rm(kept.file, { force: true });
        self.finish(job, e);
      }
    });
  }

  // A glass-evo release brought by hand runs the pairing rule's plan: in
  // place and the face told; in with the Glass zip kept from before where
  // it fits that one, the backend restarting; or kept on the player for
  // the Glass zip to come. `zip` is what the file says it is, read by the
  // route.
  runComponentFile(job, file, zip) {
    const self = this;
    self.exclusive(async function () {
      let kept = null;
      try {
        const p = await self.pairingPlan(zip, true);
        job.will = p.action;
        if (p.dropped) {
          await self.held.drop('glass');
          self.logger.info('glass: manager component: the kept Glass ' + p.dropped.version + ' zip does not go with glass-evo ' + zip.version + '; discarded');
        }
        if (p.action === 'nothing') {
          await fsp.rm(file, { force: true });
          throw new ComponentError('same-version', 'glass-evo ' + zip.version + ' is what is installed; nothing to install');
        }
        if (p.action === 'refuse-too-old') {
          await fsp.rm(file, { force: true });
          throw new ComponentError('too-old', 'glass-evo ' + zip.version + ' is older than this Glass works with (' + p.least + ')', { least: p.least });
        }
        if (p.action === 'hold-evo') {
          const verified = await self.component.verifyFile(job, file, zip.version);
          await self.held.keep('evo', file, { version: zip.version, requires: zip.requires, verified: verified });
          job.held = { kind: 'evo', version: zip.version, needs: p.needs, online: p.online };
          job.name = 'glass-evo ' + zip.version + ' (kept)';
          self.logger.info('glass: manager component: glass-evo ' + zip.version + ' kept; it needs Glass ' + p.needs + ' or later, which does not run here');
          self.finish(job, null);
          return;
        }
        if (p.action === 'install-evo') {
          const result = await self.component.installFile(job, file);
          job.name = 'glass-evo ' + result.to;
          self.plugin.componentChanged();
          await self.pruneHeld();
          self.finish(job, null);
          return;
        }
        // Both: the glass-evo first, held to the Glass that will run, then
        // the kept Glass as the online path's upgrade goes.
        kept = await self.held.take('glass');
        job.kind = 'upgrade';
        job.target = kept.version;
        await self.component.installFile(job, file, { glass: kept.version, least: kept.least || self.component.least });
        self.plugin.componentChanged();
        self.logger.info('glass: manager upgrade: glass-evo ' + zip.version + ' installed from a file with the kept Glass ' + kept.version);
        let result;
        try {
          const staged = await self.updater.stageFile(job, kept.file);
          job.name = 'Glass ' + staged.version + ' · glass-evo ' + zip.version;
          await pair(self.component, staged, job, { byHand: true });
          result = await self.updater.apply(job, staged);
        } catch (e) {
          try { await self.component.rollback(); } catch (e2) { self.logger.warn('glass: manager component: not put back after the upgrade failed: ' + e2.message); }
          throw e;
        }
        job.endedAt = new Date().toISOString();
        self.logger.info('glass: manager ' + job.kind + ' from ' + result.from + ' to ' + result.to + ' from the kept file: plugin replaced, backend restarting');
      } catch (e) {
        await fsp.rm(file, { force: true });
        if (kept) await fsp.rm(kept.file, { force: true });
        self.finish(job, e);
      }
    });
  }

  runUpload(job, file, name) {
    const self = this;
    self.exclusive(async function () {
      try {
        job.state = 'checking';
        const zip = await Zip.open(file);
        try {
          const found = await unitsOf(zip, name);
          if (found.units.length === 0) throw new ZipError('bad-theme', found.problems.join('; '));
          job.state = 'unpacking';
          job.folders = await self.unpack(zip, found.units, job);
        } finally {
          await zip.close();
        }
        for (const f of job.folders) {
          await self.catalog.forgetFolder(f.install, f.folder);
        }
        await self.afterInstall(job);
        self.finish(job, null);
      } catch (e) {
        self.finish(job, e);
      } finally {
        await fsp.rm(file, { force: true });
      }
    });
  }

  async unpack(zip, units, job) {
    const folders = [];
    for (const unit of units) {
      const root = unit.install === 'templates' ? this.paths.meterBase : this.paths.spectrumBase;
      await fsp.mkdir(root, { recursive: true });
      const result = await extractUnit(zip, unit, root, {
        onProgress: function (done, total) { job.progress = { done: done, total: total }; }
      });
      // The themes belong to the player's user, whoever unpacked them.
      await ownTree(path.join(root, result.folder), this.previews.uid, this.previews.gid);
      folders.push({ install: unit.install, folder: result.folder, kind: unit.kind, files: result.files, bytes: result.bytes, names: unit.names });
    }
    return folders;
  }

  // After folders landed: the plugin re-reads its lists, and the meter
  // folders get their previews drawn in the background.
  async afterInstall(job) {
    const self = this;
    try { self.plugin.afterThemesChanged(job.folders); } catch (e) {
      self.logger.warn('glass: manager after install: ' + e.message);
    }
    job.state = 'rendering';
    for (const f of job.folders) {
      if (f.install !== 'templates') continue;
      const metersFile = path.join(self.paths.meterBase, f.folder, 'meters.txt');
      self.previews.ensure(f.folder, metersFile, true).catch(function (e) {
        self.logger.warn('glass: manager preview of ' + f.folder + ': ' + e.message);
      });
    }
  }

  // The four files of a backup out of a zip into a staging directory. They
  // may sit at the zip root or under one folder.
  async unpackBackup(file, staging) {
    const zip = await Zip.open(file);
    try {
      const manifest = zip.entries.find(function (e) { return e.isRegular && path.basename(e.name) === 'manifest.json' && e.name.split('/').length <= 2; });
      if (!manifest) throw new ZipError('bad-backup', 'no manifest.json in the zip');
      const prefix = manifest.name.slice(0, manifest.name.length - 'manifest.json'.length);
      await fsp.mkdir(staging, { recursive: true });
      for (const name of BACKUP_FILES) {
        const entry = zip.entries.find(function (e) { return e.isRegular && e.name === prefix + name; });
        if (!entry) throw new ZipError('bad-backup', name + ' is missing from the zip');
        if (entry.size > MAX_BACKUP_FILE_BYTES) throw new ZipError('too-large', name + ' is larger than a backup file can be');
        await fsp.writeFile(path.join(staging, name), await zip.read(entry));
      }
    } finally {
      await zip.close();
    }
  }

  // The request body into a file, capped.
  receive(req, file, limit) {
    return new Promise(function (resolve, reject) {
      const out = fs.createWriteStream(file);
      let received = 0;
      let failed = false;
      const fail = function (code, message) {
        if (failed) return;
        failed = true;
        const e = new Error(message);
        e.code = code;
        out.destroy();
        req.destroy();
        reject(e);
      };
      req.on('data', function (chunk) {
        received += chunk.length;
        if (received > limit) return fail('too-large', 'the upload is larger than allowed');
      });
      req.on('error', function (e) { fail('network', e.message); });
      out.on('error', function (e) { fail('write', e.message); });
      out.on('finish', function () {
        if (failed) return;
        if (received === 0) return fail('empty', 'the upload is empty');
        resolve(received);
      });
      req.pipe(out);
    });
  }
}

// The tap's rings under /dev/shm, from their headers: the stream, the
// sequence, and whether the writer wrote within the last seconds (the
// display's own notion of a live ring). Times are the monotonic clock.
const RING_DIR = '/dev/shm';
const RING_PREFIX = 'glasstap.';
const RING_LIVE_NS = 3000000000n;
async function readRings() {
  let names = [];
  try {
    names = (await fsp.readdir(RING_DIR)).filter(function (n) { return n.startsWith(RING_PREFIX); });
  } catch (e) {
    return [];
  }
  const now = process.hrtime.bigint();
  const rings = [];
  for (const name of names) {
    let fd = null;
    try {
      fd = await fsp.open(path.join(RING_DIR, name), 'r');
      const header = Buffer.alloc(64);
      const { bytesRead } = await fd.read(header, 0, 64, 0);
      if (bytesRead < 64 || header.toString('latin1', 0, 8) !== 'GLASSTAP') continue;
      const written = header.readBigUInt64LE(56);
      // A write stamped a hair ahead of this reading counts as now, as the
      // display's own rule has it.
      const ago = written === 0n ? null : (written > now ? 0n : now - written);
      const parts = name.slice(RING_PREFIX.length).split('.');
      rings.push({
        name: name,
        tag: parts[0],
        pid: header.readUInt32LE(40),
        rate: header.readUInt32LE(16),
        channels: header.readUInt32LE(20),
        seq: Number(header.readBigUInt64LE(48)),
        writtenAgoMs: ago === null ? null : Number(ago / 1000000n),
        live: ago !== null && ago >= 0n && ago < RING_LIVE_NS
      });
    } catch (e) { /* a ring going away */ } finally {
      if (fd) await fd.close().catch(function () { });
    }
  }
  rings.sort(function (a, b) { return (a.writtenAgoMs === null ? Infinity : a.writtenAgoMs) - (b.writtenAgoMs === null ? Infinity : b.writtenAgoMs); });
  return rings;
}

// Give a tree to a user, when this process may. Nothing to do otherwise.
async function ownTree(dir, uid, gid) {
  if (uid === undefined || typeof process.getuid !== 'function' || process.getuid() !== 0) return;
  const walk = async function (p) {
    await fsp.chown(p, uid, gid);
    const stat = await fsp.lstat(p);
    if (!stat.isDirectory()) return;
    for (const name of await fsp.readdir(p)) await walk(path.join(p, name));
  };
  try {
    await walk(dir);
  } catch (e) { /* the files are still readable by everyone */ }
}

function sameUnits(found, expected) {
  if (!Array.isArray(expected) || found.length !== expected.length) return false;
  const key = function (u) { return u.install + '|' + u.folder + '|' + u.from; };
  const a = found.map(key).sort();
  const b = expected.map(key).sort();
  return a.every(function (k, i) { return k === b[i]; });
}

function failure(e) {
  if (!e) return { error: 'unknown', message: '' };
  const code = (e instanceof ZipError || e instanceof CatalogError || e instanceof UpdateError || e.code) ? String(e.code) : 'error';
  return { error: code, message: String(e.message || e) };
}

module.exports = { Manager: Manager, DEFAULT_PORT: DEFAULT_PORT, sameUnits: sameUnits };

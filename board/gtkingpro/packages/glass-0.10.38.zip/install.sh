#!/bin/bash
# Glass installer. Runs as root through the plugin manager; its output is
# shown in the install dialog and a non-zero exit fails the install.
echo "Installing Glass"

ARCH=$(cat /etc/os-release | grep ^VOLUMIO_ARCH | tr -d 'VOLUMIO_ARCH="')
VARIANT=$(cat /etc/os-release | grep ^VOLUMIO_VARIANT | tr -d 'VOLUMIO_VARIANT="')
HARDWARE=$(cat /etc/os-release | grep ^VOLUMIO_HARDWARE | tr -d 'VOLUMIO_HARDWARE="')

PLUGIN_DIR="/data/plugins/user_interface/glass"
DATA_DIR="/data/INTERNAL/glass"
LEGACY_DIR="/data/plugins/user_interface/peppy_screensaver"
LEGACY_DATA="/data/INTERNAL/peppy_screensaver"
RENDER_MARKER="/etc/glass_render_group_added"

# A refused install leaves nothing behind, so the next attempt starts clean.
refuse() {
  echo ""
  echo "$@"
  rm -rf "$PLUGIN_DIR"
  exit 1
}

if [ -z "$ARCH" ]; then
  refuse "ERROR: Could not detect the Volumio architecture"
fi
echo "Architecture: $ARCH, variant: ${VARIANT:-unknown}, hardware: ${HARDWARE:-unknown}"

# =============================================================================
# GUARD: Glass replaces PeppyMeter Screensaver; the two cannot share the audio path
# =============================================================================
if [ -d "$LEGACY_DIR" ] && [ -f /data/configuration/plugins.json ]; then
  LEGACY_ENABLED=$(node -e 'try { var d = require("/data/configuration/plugins.json"); var p = d.user_interface && d.user_interface.peppy_screensaver; console.log(p && p.enabled && p.enabled.value === true ? "yes" : "no"); } catch (e) { console.log("no"); }' 2>/dev/null)
  if [ "$LEGACY_ENABLED" = "yes" ]; then
    refuse "ERROR: PeppyMeter Screensaver is enabled.
Glass replaces PeppyMeter Screensaver and cannot be installed while it is enabled.
Disable PeppyMeter Screensaver under Plugins, then install Glass again.
Your themes and settings are taken over."
  fi
fi

# =============================================================================
# CHECK: the display binary for this machine. The unzip does not keep modes.
# =============================================================================
chmod +x "$PLUGIN_DIR"/bin/*/glass "$PLUGIN_DIR"/bin/*/tapdump "$PLUGIN_DIR"/bin/*/glass-serve "$PLUGIN_DIR/run_glass.sh" 2>/dev/null || true
if [ ! -x "$PLUGIN_DIR/bin/$ARCH/glass" ]; then
  refuse "ERROR: no display binary for architecture $ARCH (available: $(ls "$PLUGIN_DIR/bin" 2>/dev/null | tr '\n' ' '))"
fi
chmod +x "$PLUGIN_DIR/run_glass.sh"

# =============================================================================
# INSTALL: runtime dependencies
# =============================================================================
# SDL2, and the two libraries SDL loads by name to draw on a screen of its
# own, where no X server runs: EGL and OpenGL. SDL's package does not depend
# on them; a player with a kiosk has them through its X server, a player
# without one has not, and the display then dies at once with "EGL not
# initialized".
installed() {
  dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}
NEEDED_PKGS=""
for pkg in libsdl2-2.0-0 libegl1 libgl1; do
  if ! installed "$pkg"; then
    NEEDED_PKGS="$NEEDED_PKGS $pkg"
  fi
done
if [ -n "$NEEDED_PKGS" ]; then
  echo "Installing:$NEEDED_PKGS"
  apt-get update
  apt-get install -y $NEEDED_PKGS
  for pkg in $NEEDED_PKGS; do
    if ! installed "$pkg"; then
      echo "WARNING: $pkg could not be installed. The display cannot draw without it;"
      echo "         with the player on the internet run: sudo apt-get install -y $pkg"
    fi
  done
fi

# =============================================================================
# INSTALL: the tap, the ALSA scope that measures what plays
# =============================================================================
if [ ! -f "$PLUGIN_DIR/lib/$ARCH/libglasstap.so" ]; then
  refuse "ERROR: no tap library for architecture $ARCH"
fi
ln -sf "$PLUGIN_DIR/lib/$ARCH/libglasstap.so" "$PLUGIN_DIR/lib/libglasstap.so"
echo "Tap: $PLUGIN_DIR/lib/$ARCH/libglasstap.so"

# =============================================================================
# SETUP: the engine's configuration files live under the data folder, which
# every install leaves alone. They are not made here: the plugin makes them
# at its start, from a live file an older release kept in the plugin folder
# (the Manager's update puts those back only after this script has run),
# else from the templates.
# =============================================================================
mkdir -p "$DATA_DIR/config" "$PLUGIN_DIR/asound"

# =============================================================================
# SETUP: themes. Adopt what PeppyMeter Screensaver left, then add the bundled ones.
# =============================================================================
mkdir -p "$DATA_DIR"
# The themes are brought in once, when Glass's own theme folder is first made:
# a later install or upgrade leaves that folder as the listener keeps it, so
# a theme removed stays removed.
FIRST_THEMES=0
[ -d "$DATA_DIR/templates" ] || FIRST_THEMES=1
if [ "$FIRST_THEMES" = 1 ] && [ -d "$LEGACY_DATA/templates" ]; then
  # PeppyMeter Screensaver's themes, still installed (disabled) or uninstalled
  # with its themes preserved: copied into Glass's own folder; its folder is
  # left as it was, for a return to that plugin, and the manager's System
  # tab offers to wipe it.
  echo "Copying PeppyMeter Screensaver themes..."
  FREE_KB=$(df -Pk "$DATA_DIR" | awk 'NR==2 {print $4}')
  NEED_KB=$(du -sk "$LEGACY_DATA" | awk '{print $1}')
  if [ "$FREE_KB" -gt $((NEED_KB + 51200)) ]; then
    mkdir -p "$DATA_DIR/templates" "$DATA_DIR/templates_spectrum" "$DATA_DIR/backups"
    cp -rn "$LEGACY_DATA/templates/." "$DATA_DIR/templates/" 2>/dev/null || true
    [ -d "$LEGACY_DATA/templates_spectrum" ] && cp -rn "$LEGACY_DATA/templates_spectrum/." "$DATA_DIR/templates_spectrum/" 2>/dev/null || true
    [ -d "$LEGACY_DATA/backups" ] && cp -rn "$LEGACY_DATA/backups/." "$DATA_DIR/backups/" 2>/dev/null || true
    [ -f "$LEGACY_DATA/.preserve" ] && touch "$DATA_DIR/.preserve"
  else
    echo "Not enough free space to copy the themes ($NEED_KB kB needed, $FREE_KB kB free); install them from the catalog later."
  fi
fi
mkdir -p "$DATA_DIR/templates" "$DATA_DIR/templates_spectrum"
# The bundled themes the same: seeded with the folder, never put back after.
if [ -d "$PLUGIN_DIR/templates" ]; then
  [ "$FIRST_THEMES" = 1 ] && cp -rn "$PLUGIN_DIR/templates/." "$DATA_DIR/templates/"
  rm -rf "$PLUGIN_DIR/templates"
fi
if [ -d "$PLUGIN_DIR/templates_spectrum" ]; then
  [ "$FIRST_THEMES" = 1 ] && cp -rn "$PLUGIN_DIR/templates_spectrum/." "$DATA_DIR/templates_spectrum/"
  rm -rf "$PLUGIN_DIR/templates_spectrum"
fi
chmod -R 755 "$DATA_DIR"
chown -R volumio:volumio "$DATA_DIR"
chown -R volumio:volumio "$PLUGIN_DIR"

# =============================================================================
# SETUP: X11 access on kiosk products and x64 images
# =============================================================================
KIOSK_DEVICE="false"
if [ -f /opt/volumiokiosk.sh ] || [ "$VARIANT" = "motivo" ] || [ "$VARIANT" = "primo" ]; then
  KIOSK_DEVICE="true"
fi
if [ "$KIOSK_DEVICE" = "true" ] || [ "$ARCH" = "x64" ]; then
  cat > /etc/X11/Xsession.d/50-glass-xhost << 'XHOSTEOF'
#!/bin/sh
# Let the volumio user open a window on the local X session for Glass.
xhost +SI:localuser:volumio >/dev/null 2>&1 || xhost +local: >/dev/null 2>&1
XHOSTEOF
  chmod 644 /etc/X11/Xsession.d/50-glass-xhost
  # The helper is read when an X session starts. The session running now
  # gets the same at once, or the display would be refused until the kiosk
  # starts again: the image's kiosk runs X as root and admits only root.
  X_PID=$(pgrep -xo Xorg 2>/dev/null || pgrep -xo X 2>/dev/null || true)
  if [ -n "$X_PID" ] && [ -r "/proc/$X_PID/cmdline" ] && command -v xhost >/dev/null 2>&1; then
    X_AUTH=$(tr '\0' '\n' < "/proc/$X_PID/cmdline" | sed -n '/^-auth$/{n;p;}')
    X_DISPLAY=$(tr '\0' '\n' < "/proc/$X_PID/cmdline" | grep -m1 '^:[0-9]' || true)
    if DISPLAY=${X_DISPLAY:-:0} XAUTHORITY=$X_AUTH xhost +SI:localuser:volumio >/dev/null 2>&1; then
      echo "The running X session admits the volumio user"
    else
      echo "The running X session did not take the change: the display shows once the kiosk has started again"
    fi
  fi
  if getent group render >/dev/null 2>&1; then
    if ! id -nG volumio | tr ' ' '\n' | grep -qx render; then
      usermod -aG render volumio
      touch "$RENDER_MARKER"
      echo "Added volumio to the render group (reboot required)"
    fi
  fi
fi

echo "Glass installed"
echo "plugininstallend"
